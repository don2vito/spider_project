# -*- coding: utf-8 -*-
"""API blueprint for crawl control operations."""

import logging
from flask import Blueprint, jsonify, request

from services.crawl_service import CrawlService

logger = logging.getLogger(__name__)

crawl_bp = Blueprint("crawl", __name__)

# Singleton crawl service
_crawl_service = None


def get_crawl_service():
    global _crawl_service
    if _crawl_service is None:
        _crawl_service = CrawlService()
    return _crawl_service


@crawl_bp.route("/api/crawl/start", methods=["POST"])
def start_crawl():
    """Start a crawl task."""
    data = request.get_json(silent=True) or {}
    start_page = data.get("start_page", 1)
    end_page = data.get("end_page", None)
    crawl_details = data.get("crawl_details", True)
    download_images = data.get("download_images", True)

    service = get_crawl_service()
    success = service.start_crawl(start_page, end_page, crawl_details, download_images)

    if success:
        return jsonify({"code": 0, "message": "Crawl started"})
    else:
        return jsonify({"code": 400, "message": "Crawl already running"}), 400


@crawl_bp.route("/api/crawl/stop", methods=["POST"])
def stop_crawl():
    """Stop the running crawl task."""
    service = get_crawl_service()
    service.stop_crawl()
    return jsonify({"code": 0, "message": "Stop signal sent"})


@crawl_bp.route("/api/crawl/status", methods=["GET"])
def crawl_status():
    """Get current crawl status and statistics."""
    service = get_crawl_service()
    status = service.get_status()
    return jsonify({"code": 0, "data": status})


@crawl_bp.route("/api/crawl/retry", methods=["POST"])
def retry_failed():
    """Retry crawling failed articles."""
    service = get_crawl_service()
    success = service.retry_failed()
    if success:
        return jsonify({"code": 0, "message": "Retry started"})
    else:
        return jsonify({"code": 400, "message": "No failed articles or crawl already running"}), 400
