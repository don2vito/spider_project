# -*- coding: utf-8 -*-
"""API blueprint for article detail operations."""

from flask import Blueprint, jsonify
from models.database import Database

detail_bp = Blueprint("detail", __name__)


@detail_bp.route("/api/articles/<int:article_id>", methods=["GET"])
def get_article_detail(article_id):
    """Get article detail including image list."""
    db = Database()
    article = db.get_article_detail(article_id)

    if not article:
        return jsonify({"code": 404, "message": "Article not found"}), 404

    images = db.get_article_images(article_id)

    return jsonify({
        "code": 0,
        "data": {
            "article": article,
            "images": images,
        },
    })
