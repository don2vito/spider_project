# -*- coding: utf-8 -*-
"""API blueprint for PDF download operations."""

import os
import uuid
import tempfile
import zipfile
import threading
import logging
from flask import Blueprint, jsonify, request, send_file, Response
from models.database import Database
from services.pdf_service import PDFService

logger = logging.getLogger(__name__)

download_bp = Blueprint("download", __name__)

# Track async download tasks
_download_tasks = {}
_download_lock = threading.Lock()


@download_bp.route("/api/download/<int:article_id>", methods=["GET"])
def download_single(article_id):
    """Download a single report as PDF."""
    db = Database()
    article = db.get_article_detail(article_id)

    if not article:
        return jsonify({"code": 404, "message": "Article not found"}), 404

    pdf_service = PDFService()
    try:
        pdf_path = pdf_service.generate_pdf(article_id, article.get("maintitle", ""))

        # Update PDF status in database
        db.update_article(article_id, {"pdf_status": 1})

        # Use sanitized title as download name
        from services.pdf_service import sanitize_filename
        download_name = sanitize_filename(article.get("maintitle", f"report_{article_id}")) + ".pdf"

        return send_file(
            pdf_path,
            mimetype="application/pdf",
            download_name=download_name,
            as_attachment=True,
        )
    except FileNotFoundError as e:
        return jsonify({"code": 404, "message": str(e)}), 404
    except Exception as e:
        logger.error(f"PDF generation failed for article {article_id}: {e}")
        return jsonify({"code": 500, "message": f"PDF generation failed: {str(e)}"}), 500


@download_bp.route("/api/download/batch", methods=["POST"])
def download_batch():
    """Download selected reports as a ZIP file."""
    data = request.get_json(silent=True) or {}
    article_ids = data.get("article_ids", [])

    if not article_ids:
        return jsonify({"code": 400, "message": "No article IDs provided"}), 400

    db = Database()
    pdf_service = PDFService()

    # Create temp ZIP file
    temp_zip = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
    temp_zip_path = temp_zip.name
    temp_zip.close()

    try:
        with zipfile.ZipFile(temp_zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for aid in article_ids:
                article = db.get_article_detail(aid)
                if not article:
                    continue

                try:
                    pdf_path = pdf_service.generate_pdf(aid, article.get("maintitle", ""))
                    from services.pdf_service import sanitize_filename
                    arc_name = sanitize_filename(article.get("maintitle", f"report_{aid}")) + ".pdf"
                    zf.write(pdf_path, arc_name)
                    db.update_article(aid, {"pdf_status": 1})
                except Exception as e:
                    logger.warning(f"Skipping article {aid}: {e}")
                    continue

        return send_file(
            temp_zip_path,
            mimetype="application/zip",
            download_name="reports_batch.zip",
            as_attachment=True,
        )
    except Exception as e:
        logger.error(f"Batch download failed: {e}")
        if os.path.exists(temp_zip_path):
            os.unlink(temp_zip_path)
        return jsonify({"code": 500, "message": str(e)}), 500


@download_bp.route("/api/download/all", methods=["POST"])
def download_all():
    """Start async full download task."""
    db = Database()
    all_ids = db.get_all_article_ids()

    if not all_ids:
        return jsonify({"code": 400, "message": "No articles to download"}), 400

    task_id = str(uuid.uuid4())

    with _download_lock:
        _download_tasks[task_id] = {
            "total": len(all_ids),
            "completed": 0,
            "failed": 0,
            "status": "running",
            "zip_path": None,
        }

    def _worker():
        pdf_service = PDFService()
        temp_zip = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
        temp_zip_path = temp_zip.name
        temp_zip.close()

        try:
            with zipfile.ZipFile(temp_zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for aid in all_ids:
                    if _download_tasks[task_id]["status"] == "cancelled":
                        break

                    article = db.get_article_detail(aid)
                    if not article:
                        _download_tasks[task_id]["failed"] += 1
                        continue

                    try:
                        pdf_path = pdf_service.generate_pdf(aid, article.get("maintitle", ""))
                        from services.pdf_service import sanitize_filename
                        arc_name = sanitize_filename(article.get("maintitle", f"report_{aid}")) + ".pdf"
                        zf.write(pdf_path, arc_name)
                        _download_tasks[task_id]["completed"] += 1
                    except Exception:
                        _download_tasks[task_id]["failed"] += 1

            _download_tasks[task_id]["status"] = "completed"
            _download_tasks[task_id]["zip_path"] = temp_zip_path
        except Exception as e:
            _download_tasks[task_id]["status"] = "error"
            _download_tasks[task_id]["error"] = str(e)
            if os.path.exists(temp_zip_path):
                os.unlink(temp_zip_path)

    thread = threading.Thread(target=_worker, daemon=True)
    thread.start()

    return jsonify({"code": 0, "data": {"task_id": task_id, "total": len(all_ids)}})


@download_bp.route("/api/download/progress/<task_id>", methods=["GET"])
def download_progress(task_id):
    """Get progress of an async download task."""
    with _download_lock:
        task = _download_tasks.get(task_id)

    if not task:
        return jsonify({"code": 404, "message": "Task not found"}), 404

    return jsonify({
        "code": 0,
        "data": {
            "total": task["total"],
            "completed": task["completed"],
            "failed": task["failed"],
            "status": task["status"],
        },
    })


@download_bp.route("/api/download/file/<task_id>", methods=["GET"])
def download_file(task_id):
    """Download the completed ZIP file from an async task."""
    with _download_lock:
        task = _download_tasks.get(task_id)

    if not task or task["status"] != "completed" or not task.get("zip_path"):
        return jsonify({"code": 400, "message": "File not ready"}), 400

    zip_path = task["zip_path"]
    if not os.path.exists(zip_path):
        return jsonify({"code": 404, "message": "File not found"}), 404

    return send_file(
        zip_path,
        mimetype="application/zip",
        download_name="reports_all.zip",
        as_attachment=True,
    )


@download_bp.route("/api/download/cancel/<task_id>", methods=["POST"])
def cancel_download(task_id):
    """Cancel an async download task."""
    with _download_lock:
        task = _download_tasks.get(task_id)
        if task:
            task["status"] = "cancelled"

    return jsonify({"code": 0, "message": "Cancel signal sent"})
