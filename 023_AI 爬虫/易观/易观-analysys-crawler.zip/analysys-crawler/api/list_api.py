# -*- coding: utf-8 -*-
"""API blueprint for article list operations."""

from flask import Blueprint, jsonify, request
from models.database import Database

list_bp = Blueprint("list", __name__)


@list_bp.route("/api/articles", methods=["GET"])
def get_articles():
    """Get paginated article list with optional search and filter."""
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 20, type=int)
    keyword = request.args.get("keyword", "", type=str).strip()
    classify = request.args.get("classify", "", type=str).strip()

    # Clamp values
    page = max(1, page)
    per_page = max(1, min(100, per_page))

    db = Database()
    articles, total = db.get_articles(page, per_page, keyword, classify)

    return jsonify({
        "code": 0,
        "data": {
            "articles": articles,
            "total": total,
            "page": page,
            "per_page": per_page,
            "total_pages": (total + per_page - 1) // per_page if total > 0 else 0,
        },
    })


@list_bp.route("/api/classifies", methods=["GET"])
def get_classifies():
    """Get all distinct classify values for filter dropdown."""
    db = Database()
    classifies = db.get_all_classifies()
    return jsonify({
        "code": 0,
        "data": classifies,
    })
