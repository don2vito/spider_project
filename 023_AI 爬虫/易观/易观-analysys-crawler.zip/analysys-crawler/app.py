# -*- coding: utf-8 -*-
"""Flask application entry point for Analysys Crawler."""

import os
import sys
import logging
import threading
import webbrowser

from flask import Flask, send_from_directory, send_file, Response, request

from config import FLASK_HOST, FLASK_PORT, FLASK_DEBUG, BASE_URL, REQUEST_HEADERS
from api.list_api import list_bp
from api.detail_api import detail_bp
from api.download_api import download_bp
from api.crawl_api import crawl_bp

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/crawler.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__, static_folder="static", template_folder="templates")

# Register API blueprints
app.register_blueprint(list_bp)
app.register_blueprint(detail_bp)
app.register_blueprint(download_bp)
app.register_blueprint(crawl_bp)


# ---- Frontend routes ----

@app.route("/")
def index():
    """Serve the main SPA page."""
    return send_from_directory("templates", "index.html")


@app.route("/proxy/image")
def proxy_image():
    """Proxy image requests to avoid CORS issues."""
    import requests as req_lib

    url = request.args.get("url", "")
    if not url:
        return Response(status=400)

    # Validate URL to prevent SSRF
    if not url.startswith(("http://", "https://")):
        return Response(status=400)

    # Only allow proxying to known domains
    allowed_domains = ["analysys.cn", "www.analysys.cn"]
    from urllib.parse import urlparse
    parsed = urlparse(url)
    if parsed.hostname not in allowed_domains:
        return Response(status=403)

    try:
        resp = req_lib.get(url, headers=REQUEST_HEADERS, timeout=30, stream=True)
        return Response(
            resp.iter_content(chunk_size=8192),
            content_type=resp.headers.get("Content-Type", "image/jpeg"),
        )
    except Exception as e:
        logger.error(f"Image proxy error for {url}: {e}")
        return Response(status=502)


# ---- Error handlers ----

@app.errorhandler(404)
def not_found(e):
    return {"code": 404, "message": "Not found"}, 404


@app.errorhandler(500)
def server_error(e):
    logger.error(f"Server error: {e}", exc_info=True)
    return {"code": 500, "message": "Internal server error"}, 500


def open_browser():
    """Open browser after a short delay."""
    import time
    time.sleep(2)
    url = f"http://{FLASK_HOST}:{FLASK_PORT}"
    logger.info(f"Opening browser: {url}")
    webbrowser.open(url)


if __name__ == "__main__":
    logger.info(f"Starting Analysys Crawler on http://{FLASK_HOST}:{FLASK_PORT}")

    # Open browser in background thread
    threading.Thread(target=open_browser, daemon=True).start()

    # Run Flask
    app.run(host=FLASK_HOST, port=FLASK_PORT, debug=FLASK_DEBUG)
