# -*- coding: utf-8 -*-
"""Global configuration for Analysys Crawler."""

import os

# Base paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
IMAGE_DIR = os.path.join(DATA_DIR, "images")
PDF_DIR = os.path.join(DATA_DIR, "pdfs")
LOG_DIR = os.path.join(BASE_DIR, "logs")
DB_PATH = os.path.join(DATA_DIR, "analysys.db")

# Target website
BASE_URL = "https://www.analysys.cn"
LIST_URL_TEMPLATE = BASE_URL + "/article/analysis/?p={page}"
DETAIL_URL_TEMPLATE = BASE_URL + "/article/detail/{article_id}"

# Crawl settings
TOTAL_PAGES = 393
ITEMS_PER_PAGE = 10
REQUEST_DELAY_MIN = 1.5
REQUEST_DELAY_MAX = 3.0
REQUEST_TIMEOUT = 30
MAX_RETRIES = 3
IMAGE_MAX_WORKERS = 3

# Request headers
REQUEST_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Referer": BASE_URL + "/",
    "Connection": "keep-alive",
}

# User-Agent pool for rotation
UA_POOL = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
]

# Flask settings
FLASK_HOST = "127.0.0.1"
FLASK_PORT = 5000
FLASK_DEBUG = False

# Ensure directories exist
for _dir in [DATA_DIR, IMAGE_DIR, PDF_DIR, LOG_DIR]:
    os.makedirs(_dir, exist_ok=True)
