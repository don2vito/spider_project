# -*- coding: utf-8 -*-
"""Base crawler class defining the unified interface."""

from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any


class BaseCrawler(ABC):
    """Abstract base class for all crawler layers."""

    @abstractmethod
    def fetch_list_page(self, page: int) -> Optional[List[Dict[str, Any]]]:
        """Fetch article list from a list page.

        Args:
            page: Page number (1-based).

        Returns:
            List of article dicts, or None if this layer fails.
        """
        pass

    @abstractmethod
    def fetch_detail_page(self, article_id: int) -> Optional[Dict[str, Any]]:
        """Fetch article detail including image list.

        Args:
            article_id: The article ID from the website.

        Returns:
            Dict with article detail and images, or None if this layer fails.
        """
        pass

    @abstractmethod
    def fetch_total_pages(self) -> Optional[int]:
        """Detect total number of pages from the first list page.

        Returns:
            Total page count, or None if detection fails.
        """
        pass
