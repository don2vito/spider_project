# -*- coding: utf-8 -*-
"""Three-layer crawler dispatcher with automatic fallback."""

import logging
from typing import Optional, List, Dict, Any

from crawler.base import BaseCrawler
from crawler.layer1_extractor import InitialStateExtractor
from crawler.layer2_parser import HTMLParser
from crawler.layer3_browser import BrowserCrawler

logger = logging.getLogger(__name__)


class CrawlerDispatcher:
    """Dispatches crawl requests through three layers with automatic degradation."""

    def __init__(self):
        self.layer1 = InitialStateExtractor()
        self.layer2 = HTMLParser()
        self._layer3 = None  # Lazy init (Playwright is heavy)

    @property
    def layer3(self):
        if self._layer3 is None:
            self._layer3 = BrowserCrawler()
        return self._layer3

    def fetch_list_page(self, page: int) -> Optional[List[Dict[str, Any]]]:
        """Try all three layers in order, return first successful result."""
        # Layer 1: Regex extract __INITIAL_STATE__
        try:
            result = self.layer1.fetch_list_page(page)
            if result is not None:
                logger.info(f"Page {page}: Layer 1 (regex) succeeded")
                return result
        except Exception as e:
            logger.warning(f"Page {page}: Layer 1 error: {e}")

        # Layer 2: BeautifulSoup HTML parsing
        try:
            result = self.layer2.fetch_list_page(page)
            if result is not None:
                logger.warning(f"Page {page}: Layer 1 failed, Layer 2 (HTML parser) succeeded")
                return result
        except Exception as e:
            logger.warning(f"Page {page}: Layer 2 error: {e}")

        # Layer 3: Playwright browser
        try:
            result = self.layer3.fetch_list_page(page)
            if result is not None:
                logger.error(f"Page {page}: Layer 1&2 failed, Layer 3 (browser) succeeded")
                return result
        except Exception as e:
            logger.error(f"Page {page}: Layer 3 error: {e}")

        logger.critical(f"Page {page}: All three layers failed")
        return None

    def fetch_detail_page(self, article_id: int) -> Optional[Dict[str, Any]]:
        """Try all three layers for detail page."""
        # Layer 1
        try:
            result = self.layer1.fetch_detail_page(article_id)
            if result is not None:
                logger.info(f"Detail {article_id}: Layer 1 succeeded")
                return result
        except Exception as e:
            logger.warning(f"Detail {article_id}: Layer 1 error: {e}")

        # Layer 2
        try:
            result = self.layer2.fetch_detail_page(article_id)
            if result is not None:
                logger.warning(f"Detail {article_id}: Layer 2 succeeded")
                return result
        except Exception as e:
            logger.warning(f"Detail {article_id}: Layer 2 error: {e}")

        # Layer 3
        try:
            result = self.layer3.fetch_detail_page(article_id)
            if result is not None:
                logger.error(f"Detail {article_id}: Layer 3 succeeded")
                return result
        except Exception as e:
            logger.error(f"Detail {article_id}: Layer 3 error: {e}")

        logger.critical(f"Detail {article_id}: All layers failed")
        return None

    def fetch_total_pages(self) -> Optional[int]:
        """Detect total number of pages."""
        try:
            result = self.layer1.fetch_total_pages()
            if result:
                return result
        except Exception as e:
            logger.warning(f"Total pages detection Layer 1 error: {e}")

        try:
            result = self.layer2.fetch_total_pages()
            if result:
                return result
        except Exception as e:
            logger.warning(f"Total pages detection Layer 2 error: {e}")

        try:
            result = self.layer3.fetch_total_pages()
            if result:
                return result
        except Exception as e:
            logger.error(f"Total pages detection Layer 3 error: {e}")

        return None

    def cleanup(self):
        """Clean up resources (especially Playwright browser)."""
        if self._layer3:
            self._layer3._close_browser()
