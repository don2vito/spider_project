# -*- coding: utf-8 -*-
"""Image downloader with concurrent support."""

import os
import logging
import random
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict

from config import IMAGE_DIR, REQUEST_HEADERS, UA_POOL, REQUEST_TIMEOUT

logger = logging.getLogger(__name__)


class ImageDownloader:
    """Download report images with concurrent thread pool."""

    def __init__(self, max_workers=3):
        self.max_workers = max_workers
        self.session = requests.Session()

    def _get_headers(self):
        headers = REQUEST_HEADERS.copy()
        headers["User-Agent"] = random.choice(UA_POOL)
        return headers

    def download_article_images(self, article_id: int, images: List[Dict]) -> List[Dict]:
        """Download all images for an article.

        Args:
            article_id: Article ID.
            images: List of dicts with 'page_number' and 'image_url'.

        Returns:
            List of result dicts with download status.
        """
        article_dir = os.path.join(IMAGE_DIR, str(article_id))
        os.makedirs(article_dir, exist_ok=True)

        results = []
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {}
            for img in images:
                page_num = img.get("page_number", 0)
                url = img.get("image_url", "")
                if not url:
                    continue

                # Determine file extension
                ext = self._get_extension(url)
                filename = f"{page_num:03d}{ext}"
                local_path = os.path.join(article_dir, filename)

                future = executor.submit(self._download_one, url, local_path)
                futures[future] = {"page_number": page_num, "url": url, "local_path": local_path}

            for future in as_completed(futures):
                info = futures[future]
                try:
                    file_size = future.result()
                    results.append({
                        "page_number": info["page_number"],
                        "url": info["url"],
                        "local_path": info["local_path"],
                        "status": "success",
                        "file_size": file_size,
                    })
                except Exception as e:
                    logger.error(f"Failed to download {info['url']}: {e}")
                    results.append({
                        "page_number": info["page_number"],
                        "url": info["url"],
                        "local_path": "",
                        "status": "error",
                        "error": str(e),
                    })

        return results

    def _download_one(self, url: str, local_path: str) -> int:
        """Download a single image file.

        Returns:
            File size in bytes.
        """
        # Skip if already downloaded and non-empty
        if os.path.exists(local_path) and os.path.getsize(local_path) > 0:
            return os.path.getsize(local_path)

        resp = self.session.get(
            url,
            headers=self._get_headers(),
            timeout=60,
            stream=True,
        )
        resp.raise_for_status()

        file_size = 0
        with open(local_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    file_size += len(chunk)

        return file_size

    @staticmethod
    def _get_extension(url: str) -> str:
        """Extract file extension from URL, default to .jpg."""
        url_path = url.split("?")[0].lower()
        for ext in [".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"]:
            if url_path.endswith(ext):
                return ext
        return ".jpg"
