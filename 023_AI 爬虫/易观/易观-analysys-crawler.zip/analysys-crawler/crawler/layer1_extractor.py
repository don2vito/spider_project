# -*- coding: utf-8 -*-
"""Layer 1: Extract data from window.__INITIAL_STATE__ JSON in SSR pages."""

import re
import json
import logging
import random
import requests
from urllib.parse import unquote

from crawler.base import BaseCrawler
from config import (
    LIST_URL_TEMPLATE, DETAIL_URL_TEMPLATE,
    REQUEST_HEADERS, UA_POOL, REQUEST_TIMEOUT, MAX_RETRIES,
    BASE_URL,
)

logger = logging.getLogger(__name__)


class InitialStateExtractor(BaseCrawler):
    """Extract structured data from the __INITIAL_STATE__ JSON embedded in SSR pages."""

    def __init__(self):
        self.session = requests.Session()

    def _get_headers(self):
        headers = REQUEST_HEADERS.copy()
        headers["User-Agent"] = random.choice(UA_POOL)
        return headers

    def _request_with_retry(self, url, retries=None):
        """Make HTTP request with exponential backoff retry."""
        retries = retries or MAX_RETRIES
        for attempt in range(retries):
            try:
                resp = self.session.get(url, headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
                resp.raise_for_status()
                resp.encoding = "utf-8"
                return resp
            except Exception as e:
                logger.warning(f"Request failed (attempt {attempt + 1}/{retries}): {url} - {e}")
                if attempt < retries - 1:
                    import time
                    time.sleep(2 ** attempt)
                else:
                    logger.error(f"All retries exhausted for: {url}")
                    return None
        return None

    def _extract_initial_state(self, html):
        """Extract and parse window.__INITIAL_STATE__ JSON from HTML."""
        # Try multiple patterns to match different formatting
        patterns = [
            r'window\.__INITIAL_STATE__\s*=\s*(\{.*?\})\s*;?\s*</script>',
            r'window\.__INITIAL_STATE__\s*=\s*(\{.*?\})\s*;?',
            r'__INITIAL_STATE__\s*=\s*(\{.*?\})\s*;?\s*</script>',
        ]
        for pattern in patterns:
            match = re.search(pattern, html, re.DOTALL)
            if match:
                try:
                    state = json.loads(match.group(1))
                    # Decode any URL-encoded JSON string values
                    state = self._decode_state_values(state)
                    return state
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse __INITIAL_STATE__ JSON: {e}")
                    continue
        return None

    def _decode_state_values(self, obj):
        """Recursively decode URL-encoded JSON string values in the state dict."""
        if isinstance(obj, dict):
            decoded = {}
            for k, v in obj.items():
                if isinstance(v, str):
                    # Check if this is a URL-encoded JSON string
                    try:
                        decoded_v = unquote(v)
                        if decoded_v != v and decoded_v.startswith('{'):
                            try:
                                parsed = json.loads(decoded_v)
                                # Recursively decode nested values
                                decoded[k] = self._decode_state_values(parsed)
                                continue
                            except (json.JSONDecodeError, ValueError):
                                pass
                    except Exception:
                        pass
                    decoded[k] = v
                elif isinstance(v, (dict, list)):
                    decoded[k] = self._decode_state_values(v)
                else:
                    decoded[k] = v
            return decoded
        elif isinstance(obj, list):
            return [self._decode_state_values(item) for item in obj]
        return obj

    def _find_articles_in_state(self, state):
        """Recursively search for article list in the state dict."""
        # Known possible paths based on research
        possible_paths = [
            ["article", "analysis", "list"],
            ["data", "list"],
            ["list"],
            ["articleList"],
            ["articles"],
        ]

        for path in possible_paths:
            obj = state
            for key in path:
                if isinstance(obj, dict) and key in obj:
                    obj = obj[key]
                else:
                    obj = None
                    break
            if isinstance(obj, list) and len(obj) > 0:
                # Validate that items look like articles
                if isinstance(obj[0], dict) and "maintitle" in obj[0]:
                    return obj

        # Fallback: recursive search for a list containing dicts with "maintitle"
        def _search(obj, depth=0):
            if depth > 10:
                return None
            if isinstance(obj, list) and len(obj) > 0:
                if isinstance(obj[0], dict) and "maintitle" in obj[0]:
                    return obj
            elif isinstance(obj, dict):
                for v in obj.values():
                    result = _search(v, depth + 1)
                    if result:
                        return result
            return None

        return _search(state)

    def _find_total_in_state(self, state):
        """Find total article count in state."""
        possible_keys = ["total", "totalCount", "totalPage", "totalNum"]
        for path_combo in [
            ["article", "analysis", "total"],
            ["article", "analysis", "totalPage"],
            ["data", "total"],
            ["total"],
        ]:
            obj = state
            for key in path_combo:
                if isinstance(obj, dict) and key in obj:
                    obj = obj[key]
                else:
                    obj = None
                    break
            if isinstance(obj, (int, float)) and obj > 0:
                return int(obj)
        return None

    def _parse_article(self, item):
        """Parse a single article item from the state into a normalized dict."""
        article_id = item.get("id")
        if not article_id:
            logger.warning("Skipping article without id")
            return None

        # Ensure id is integer
        try:
            article_id = int(article_id)
        except (ValueError, TypeError) as e:
            logger.warning(f"Invalid article id: {article_id}, error: {e}")
            return None

        # Build cover image URL
        cover_image = ""
        images = item.get("images", [])
        if images and len(images) > 0:
            first_img = images[0] if isinstance(images[0], str) else images[0].get("path", "")
            if first_img:
                cover_image = first_img if first_img.startswith("http") else BASE_URL + first_img

        # Ensure numeric fields
        try:
            clickcount = int(item.get("clickcount", 0) or 0)
        except (ValueError, TypeError):
            clickcount = 0

        return {
            "id": article_id,
            "maintitle": str(item.get("maintitle", "")).strip(),
            "summary": str(item.get("summary", "")).strip(),
            "classify": str(item.get("classify", "")).strip(),
            "field": str(item.get("field", "")).strip(),
            "source": str(item.get("source", "")).strip(),
            "author": str(item.get("author", "")).strip(),
            "clickcount": clickcount,
            "publishdate": str(item.get("publishdate", "")).strip(),
            "cover_image": cover_image,
            "detail_url": f"/article/detail/{article_id}",
        }

    def fetch_list_page(self, page):
        url = LIST_URL_TEMPLATE.format(page=page)
        resp = self._request_with_retry(url)
        if not resp:
            return None

        state = self._extract_initial_state(resp.text)
        if not state:
            logger.warning(f"Layer 1: Could not extract __INITIAL_STATE__ from page {page}")
            return None

        articles_raw = self._find_articles_in_state(state)
        if not articles_raw:
            logger.warning(f"Layer 1: Could not find article list in state for page {page}")
            return None

        articles = []
        for item in articles_raw:
            parsed = self._parse_article(item)
            if parsed:
                articles.append(parsed)

        logger.info(f"Layer 1: Extracted {len(articles)} articles from page {page}")
        return articles

    def fetch_detail_page(self, article_id):
        url = DETAIL_URL_TEMPLATE.format(article_id=article_id)
        resp = self._request_with_retry(url)
        if not resp:
            return None

        state = self._extract_initial_state(resp.text)
        if not state:
            logger.warning(f"Layer 1: Could not extract __INITIAL_STATE__ for detail {article_id}")
            return None

        # Find article detail in state
        detail = None
        for key in ["article", "detail", "data"]:
            if key in state and isinstance(state[key], dict):
                detail = state[key]
                break

        if not detail:
            # Try recursive search for dict with maintitle
            def _find_detail(obj, depth=0):
                if depth > 8:
                    return None
                if isinstance(obj, dict):
                    if "maintitle" in obj and ("images" in obj or "summary" in obj or "description" in obj):
                        return obj
                    for v in obj.values():
                        result = _find_detail(v, depth + 1)
                        if result:
                            return result
                return None
            detail = _find_detail(state)

        if not detail:
            logger.warning(f"Layer 1: Could not find article detail for {article_id}")
            return None

        # Extract images
        images = []
        raw_images = detail.get("images", [])
        for idx, img in enumerate(raw_images):
            if isinstance(img, str):
                img_url = img
            elif isinstance(img, dict):
                img_url = img.get("path", "")
            else:
                continue

            if img_url:
                if not img_url.startswith("http"):
                    img_url = BASE_URL + img_url
                images.append({
                    "page_number": idx + 1,
                    "image_url": img_url,
                })

        return {
            "id": article_id,
            "maintitle": detail.get("maintitle", ""),
            "summary": detail.get("summary", "") or detail.get("description", ""),
            "classify": detail.get("classify", ""),
            "field": detail.get("field", ""),
            "images": images,
            "image_count": len(images),
        }

    def fetch_total_pages(self):
        url = LIST_URL_TEMPLATE.format(page=1)
        resp = self._request_with_retry(url)
        if not resp:
            return None

        state = self._extract_initial_state(resp.text)
        if not state:
            return None

        total = self._find_total_in_state(state)
        if total:
            # If total is article count, convert to page count
            items_per_page = 10
            if total > items_per_page:
                return (total + items_per_page - 1) // items_per_page
            return total

        return None
