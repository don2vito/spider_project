# -*- coding: utf-8 -*-
"""Layer 2: Parse HTML DOM using BeautifulSoup."""

import logging
import random
import requests
from bs4 import BeautifulSoup

from crawler.base import BaseCrawler
from config import (
    LIST_URL_TEMPLATE, DETAIL_URL_TEMPLATE,
    REQUEST_HEADERS, UA_POOL, REQUEST_TIMEOUT, MAX_RETRIES,
    BASE_URL,
)

logger = logging.getLogger(__name__)


class HTMLParser(BaseCrawler):
    """Parse SSR-rendered HTML using BeautifulSoup selectors."""

    def __init__(self):
        self.session = requests.Session()

    def _get_headers(self):
        headers = REQUEST_HEADERS.copy()
        headers["User-Agent"] = random.choice(UA_POOL)
        return headers

    def _request_with_retry(self, url, retries=None):
        retries = retries or MAX_RETRIES
        for attempt in range(retries):
            try:
                resp = self.session.get(url, headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
                resp.raise_for_status()
                resp.encoding = "utf-8"
                return resp
            except Exception as e:
                logger.warning(f"Layer 2 request failed (attempt {attempt + 1}/{retries}): {url} - {e}")
                if attempt < retries - 1:
                    import time
                    time.sleep(2 ** attempt)
                else:
                    return None
        return None

    def fetch_list_page(self, page):
        url = LIST_URL_TEMPLATE.format(page=page)
        resp = self._request_with_retry(url)
        if not resp:
            return None

        soup = BeautifulSoup(resp.text, "lxml")
        articles = []

        # Try multiple selectors for article list items
        selectors = [
            ".article-list .item",
            ".article-list .article-item",
            ".analysis-list .item",
            ".list-content .item",
            ".col-md-9 .item",
            "li.article-item",
            ".news-list .item",
        ]

        items = []
        for sel in selectors:
            items = soup.select(sel)
            if items:
                logger.info(f"Layer 2: Found {len(items)} items with selector '{sel}'")
                break

        if not items:
            # Fallback: try to find links that match detail URL pattern
            all_links = soup.find_all("a", href=lambda h: h and "/article/detail/" in str(h))
            if all_links:
                logger.info(f"Layer 2: Found {len(all_links)} detail links as fallback")
                seen_ids = set()
                for link in all_links:
                    href = link.get("href", "")
                    aid = href.split("/detail/")[-1].split("?")[0].split("/")[0]
                    if aid and aid not in seen_ids:
                        seen_ids.add(aid)
                        title = link.get_text(strip=True)
                        parent = link.find_parent(["div", "li", "article"])
                        summary = ""
                        if parent:
                            p_tag = parent.find("p")
                            if p_tag:
                                summary = p_tag.get_text(strip=True)
                        articles.append({
                            "id": int(aid) if aid.isdigit() else 0,
                            "maintitle": title,
                            "summary": summary,
                            "classify": "",
                            "field": "",
                            "source": "",
                            "author": "",
                            "clickcount": 0,
                            "publishdate": "",
                            "cover_image": "",
                            "detail_url": href if href.startswith("http") else BASE_URL + href,
                        })
                return articles if articles else None

        for item in items:
            try:
                # Extract title
                title_tag = item.select_one(".title, .article-title, h3 a, h2 a, .name a")
                title = title_tag.get_text(strip=True) if title_tag else ""

                # Extract link
                link_tag = item.select_one("a[href*='/article/detail/']")
                href = link_tag.get("href", "") if link_tag else ""
                article_id = href.split("/detail/")[-1].split("?")[0].split("/")[0] if href else ""

                # Extract summary
                summary_tag = item.select_one(".summary, .desc, .description, p")
                summary = summary_tag.get_text(strip=True) if summary_tag else ""

                # Extract classify
                classify_tag = item.select_one(".classify, .tag, .category, .label")
                classify = classify_tag.get_text(strip=True) if classify_tag else ""

                # Extract date
                date_tag = item.select_one(".date, .time, .publish-date, .pub-time")
                publishdate = date_tag.get_text(strip=True) if date_tag else ""

                # Extract cover image
                img_tag = item.select_one("img")
                cover = img_tag.get("src", "") or img_tag.get("data-src", "") if img_tag else ""
                if cover and not cover.startswith("http"):
                    cover = BASE_URL + cover

                if article_id and title:
                    articles.append({
                        "id": int(article_id) if article_id.isdigit() else 0,
                        "maintitle": title,
                        "summary": summary,
                        "classify": classify,
                        "field": "",
                        "source": "",
                        "author": "",
                        "clickcount": 0,
                        "publishdate": publishdate,
                        "cover_image": cover,
                        "detail_url": href if href.startswith("http") else BASE_URL + href,
                    })
            except Exception as e:
                logger.warning(f"Layer 2: Error parsing item: {e}")
                continue

        if articles:
            logger.info(f"Layer 2: Parsed {len(articles)} articles from page {page}")
            return articles
        return None

    def fetch_detail_page(self, article_id):
        url = DETAIL_URL_TEMPLATE.format(article_id=article_id)
        resp = self._request_with_retry(url)
        if not resp:
            return None

        soup = BeautifulSoup(resp.text, "lxml")

        # Extract title
        title_tag = soup.select_one("h1, .article-title, .detail-title")
        title = title_tag.get_text(strip=True) if title_tag else ""

        # Extract summary
        summary_tag = soup.select_one(".summary, .abstract, .description, .article-summary")
        summary = summary_tag.get_text(strip=True) if summary_tag else ""

        # Extract images from the article content area
        images = []
        content_area = soup.select_one(".article-content, .detail-content, .content, .article-body")
        if content_area:
            img_tags = content_area.find_all("img")
        else:
            img_tags = soup.find_all("img", src=lambda s: s and "uploadcmsimages" in str(s))

        for idx, img in enumerate(img_tags):
            src = img.get("src", "") or img.get("data-src", "")
            if src and ("uploadcmsimages" in src or "/upload/" in src):
                if not src.startswith("http"):
                    src = BASE_URL + src
                images.append({
                    "page_number": idx + 1,
                    "image_url": src,
                })

        if not title and not images:
            return None

        return {
            "id": article_id,
            "maintitle": title,
            "summary": summary,
            "classify": "",
            "field": "",
            "images": images,
            "image_count": len(images),
        }

    def fetch_total_pages(self):
        url = LIST_URL_TEMPLATE.format(page=1)
        resp = self._request_with_retry(url)
        if not resp:
            return None

        soup = BeautifulSoup(resp.text, "lxml")

        # Look for pagination links
        page_links = soup.select(".pagination a, .pager a, .page a, .pg_link")
        max_page = 0
        for link in page_links:
            href = link.get("href", "")
            text = link.get_text(strip=True)
            # Try to extract page number from href or text
            import re
            match = re.search(r'p=(\d+)', href)
            if match:
                page_num = int(match.group(1))
                max_page = max(max_page, page_num)
            elif text.isdigit():
                max_page = max(max_page, int(text))

        # Also look for "last" or "total" indicators
        total_text = soup.select_one(".total, .page-info, .pagination-info")
        if total_text:
            import re
            match = re.search(r'共\s*(\d+)\s*页', total_text.get_text())
            if match:
                return int(match.group(1))

        return max_page if max_page > 0 else None
