# -*- coding: utf-8 -*-
"""Layer 3: Playwright browser-based crawler as fallback."""

import logging
from typing import Optional, List, Dict, Any

from crawler.base import BaseCrawler
from config import (
    LIST_URL_TEMPLATE, DETAIL_URL_TEMPLATE,
    REQUEST_TIMEOUT, BASE_URL,
)

logger = logging.getLogger(__name__)


class BrowserCrawler(BaseCrawler):
    """Use Playwright to control a real browser for data extraction."""

    def __init__(self):
        self._playwright = None
        self._browser = None
        self._context = None
        self._initialized = False

    def _init_browser(self):
        """Lazily initialize Playwright browser."""
        if self._initialized:
            return True
        try:
            from playwright.sync_api import sync_playwright
            self._playwright = sync_playwright().start()
            self._browser = self._playwright.chromium.launch(headless=True)
            self._context = self._browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
                viewport={"width": 1920, "height": 1080},
            )
            self._initialized = True
            logger.info("Layer 3: Playwright browser initialized")
            return True
        except Exception as e:
            logger.error(f"Layer 3: Failed to initialize Playwright: {e}")
            return False

    def _close_browser(self):
        """Close browser resources."""
        try:
            if self._context:
                self._context.close()
            if self._browser:
                self._browser.close()
            if self._playwright:
                self._playwright.stop()
        except Exception:
            pass
        self._initialized = False

    def fetch_list_page(self, page):
        if not self._init_browser():
            return None

        url = LIST_URL_TEMPLATE.format(page=page)
        page_obj = None

        try:
            page_obj = self._context.new_page()
            page_obj.goto(url, wait_until="networkidle", timeout=REQUEST_TIMEOUT * 1000)

            # Wait for article list to appear
            page_obj.wait_for_selector(".article-list, .list-content, .col-md-9", timeout=15000)

            # Try to extract __INITIAL_STATE__ from JavaScript
            state = page_obj.evaluate("""() => {
                if (window.__INITIAL_STATE__) {
                    return JSON.parse(JSON.stringify(window.__INITIAL_STATE__));
                }
                return null;
            }""")

            if state:
                # Reuse Layer 1 parsing logic
                from crawler.layer1_extractor import InitialStateExtractor
                extractor = InitialStateExtractor()
                articles_raw = extractor._find_articles_in_state(state)
                if articles_raw:
                    articles = []
                    for item in articles_raw:
                        parsed = extractor._parse_article(item)
                        if parsed:
                            articles.append(parsed)
                    logger.info(f"Layer 3: Extracted {len(articles)} articles via JS eval from page {page}")
                    return articles

            # Fallback: extract from DOM
            articles_data = page_obj.evaluate("""() => {
                const items = document.querySelectorAll('.article-list .item, .list-content .item, .col-md-9 .item');
                if (items.length === 0) return null;

                return Array.from(items).map(item => {
                    const titleEl = item.querySelector('.title a, h3 a, h2 a, .name a');
                    const linkEl = item.querySelector('a[href*="/article/detail/"]');
                    const summaryEl = item.querySelector('.summary, .desc, p');
                    const classifyEl = item.querySelector('.classify, .tag, .category');
                    const dateEl = item.querySelector('.date, .time');
                    const imgEl = item.querySelector('img');

                    const href = linkEl ? linkEl.getAttribute('href') : '';
                    const articleId = href ? href.split('/detail/')[1]?.split('?')[0] : '';

                    return {
                        id: articleId ? parseInt(articleId) : 0,
                        maintitle: titleEl ? titleEl.textContent.trim() : '',
                        summary: summaryEl ? summaryEl.textContent.trim() : '',
                        classify: classifyEl ? classifyEl.textContent.trim() : '',
                        publishdate: dateEl ? dateEl.textContent.trim() : '',
                        cover_image: imgEl ? (imgEl.getAttribute('src') || imgEl.getAttribute('data-src') || '') : '',
                        detail_url: href,
                    };
                }).filter(a => a.id > 0 && a.maintitle);
            }""")

            if articles_data:
                # Normalize URLs
                for article in articles_data:
                    if article["cover_image"] and not article["cover_image"].startswith("http"):
                        article["cover_image"] = BASE_URL + article["cover_image"]
                    if article["detail_url"] and not article["detail_url"].startswith("http"):
                        article["detail_url"] = BASE_URL + article["detail_url"]
                    article.setdefault("field", "")
                    article.setdefault("source", "")
                    article.setdefault("author", "")
                    article.setdefault("clickcount", 0)

                logger.info(f"Layer 3: Extracted {len(articles_data)} articles from DOM on page {page}")
                return articles_data

            return None

        except Exception as e:
            logger.error(f"Layer 3: Error fetching page {page}: {e}")
            return None
        finally:
            if page_obj:
                try:
                    page_obj.close()
                except Exception:
                    pass

    def fetch_detail_page(self, article_id):
        if not self._init_browser():
            return None

        url = DETAIL_URL_TEMPLATE.format(article_id=article_id)
        page_obj = None

        try:
            page_obj = self._context.new_page()
            page_obj.goto(url, wait_until="networkidle", timeout=REQUEST_TIMEOUT * 1000)

            # Wait for content to load
            page_obj.wait_for_selector("h1, .article-title, .detail-content", timeout=15000)

            detail_data = page_obj.evaluate("""(articleId) => {
                const titleEl = document.querySelector('h1, .article-title, .detail-title');
                const summaryEl = document.querySelector('.summary, .abstract, .description');

                // Get images from content area
                const contentEl = document.querySelector('.article-content, .detail-content, .content, .article-body');
                const container = contentEl || document.body;
                const imgEls = container.querySelectorAll('img[src*="uploadcmsimages"], img[src*="/upload/"]');

                const images = Array.from(imgEls).map((img, idx) => ({
                    page_number: idx + 1,
                    image_url: img.getAttribute('src') || img.getAttribute('data-src') || '',
                })).filter(img => img.image_url);

                return {
                    id: articleId,
                    maintitle: titleEl ? titleEl.textContent.trim() : '',
                    summary: summaryEl ? summaryEl.textContent.trim() : '',
                    images: images,
                    image_count: images.length,
                };
            }""", article_id)

            if detail_data and (detail_data["maintitle"] or detail_data["images"]):
                # Normalize image URLs
                for img in detail_data["images"]:
                    if not img["image_url"].startswith("http"):
                        img["image_url"] = BASE_URL + img["image_url"]

                logger.info(f"Layer 3: Extracted detail for article {article_id} with {detail_data['image_count']} images")
                return detail_data

            return None

        except Exception as e:
            logger.error(f"Layer 3: Error fetching detail {article_id}: {e}")
            return None
        finally:
            if page_obj:
                try:
                    page_obj.close()
                except Exception:
                    pass

    def fetch_total_pages(self):
        if not self._init_browser():
            return None

        url = LIST_URL_TEMPLATE.format(page=1)
        page_obj = None

        try:
            page_obj = self._context.new_page()
            page_obj.goto(url, wait_until="networkidle", timeout=REQUEST_TIMEOUT * 1000)

            total = page_obj.evaluate("""() => {
                // Try __INITIAL_STATE__
                if (window.__INITIAL_STATE__) {
                    const state = window.__INITIAL_STATE__;
                    // Search for total/page info
                    for (const key of Object.keys(state)) {
                        if (typeof state[key] === 'object' && state[key] !== null) {
                            if (state[key].total) return Math.ceil(state[key].total / 10);
                            if (state[key].totalPage) return state[key].totalPage;
                        }
                    }
                }

                // Try pagination
                const pageLinks = document.querySelectorAll('.pagination a, .pager a, .pg_link');
                let maxPage = 0;
                pageLinks.forEach(link => {
                    const href = link.getAttribute('href') || '';
                    const text = link.textContent.trim();
                    const match = href.match(/p=(\\d+)/);
                    if (match) maxPage = Math.max(maxPage, parseInt(match[1]));
                    else if (text && !isNaN(text)) maxPage = Math.max(maxPage, parseInt(text));
                });
                return maxPage > 0 ? maxPage : null;
            }""")

            return int(total) if total else None

        except Exception as e:
            logger.error(f"Layer 3: Error detecting total pages: {e}")
            return None
        finally:
            if page_obj:
                try:
                    page_obj.close()
                except Exception:
                    pass
