# -*- coding: utf-8 -*-
"""Rate limiter for crawl requests."""

import time
import random
import threading
import logging

logger = logging.getLogger(__name__)


class RateLimiter:
    """Token-bucket style rate limiter with random delay."""

    def __init__(self, min_interval=1.5, max_interval=3.0):
        self.min_interval = min_interval
        self.max_interval = max_interval
        self._lock = threading.Lock()
        self._last_request_time = 0

    def wait(self):
        """Block until the next request is allowed."""
        with self._lock:
            now = time.time()
            elapsed = now - self._last_request_time
            delay = random.uniform(self.min_interval, self.max_interval)
            if elapsed < delay:
                sleep_time = delay - elapsed
                logger.debug(f"Rate limiting: sleeping {sleep_time:.2f}s")
                time.sleep(sleep_time)
            self._last_request_time = time.time()
