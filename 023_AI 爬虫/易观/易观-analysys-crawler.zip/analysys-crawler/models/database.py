# -*- coding: utf-8 -*-
"""SQLite database operations for Analysys Crawler."""

import sqlite3
import os
import logging
from config import DB_PATH

logger = logging.getLogger(__name__)


class Database:
    """SQLite database wrapper with CRUD operations."""

    def __init__(self, db_path=None):
        self.db_path = db_path or DB_PATH
        self._init_tables()

    def _get_conn(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _init_tables(self):
        conn = self._get_conn()
        try:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS articles (
                    id INTEGER PRIMARY KEY,
                    maintitle TEXT NOT NULL,
                    summary TEXT DEFAULT '',
                    classify TEXT DEFAULT '',
                    field TEXT DEFAULT '',
                    source TEXT DEFAULT '',
                    author TEXT DEFAULT '',
                    clickcount INTEGER DEFAULT 0,
                    publishdate TEXT DEFAULT '',
                    cover_image TEXT DEFAULT '',
                    detail_url TEXT DEFAULT '',
                    crawl_status INTEGER DEFAULT 0,
                    image_count INTEGER DEFAULT 0,
                    pdf_status INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS article_images (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    article_id INTEGER NOT NULL,
                    page_number INTEGER NOT NULL,
                    image_url TEXT NOT NULL,
                    local_path TEXT DEFAULT '',
                    download_status INTEGER DEFAULT 0,
                    file_size INTEGER DEFAULT 0,
                    FOREIGN KEY (article_id) REFERENCES articles(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS crawl_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    log_type TEXT DEFAULT '',
                    article_id INTEGER DEFAULT 0,
                    status TEXT DEFAULT '',
                    message TEXT DEFAULT '',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );

                CREATE INDEX IF NOT EXISTS idx_articles_crawl_status ON articles(crawl_status);
                CREATE INDEX IF NOT EXISTS idx_articles_publishdate ON articles(publishdate);
                CREATE INDEX IF NOT EXISTS idx_article_images_article ON article_images(article_id);
                CREATE INDEX IF NOT EXISTS idx_article_images_status ON article_images(download_status);
            """)
            conn.commit()
            logger.info("Database tables initialized successfully.")
        finally:
            conn.close()

    # ---- Article CRUD ----

    def insert_article(self, article_dict):
        """Insert an article. Uses INSERT OR IGNORE to avoid duplicates by id."""
        conn = self._get_conn()
        try:
            conn.execute("""
                INSERT OR IGNORE INTO articles
                (id, maintitle, summary, classify, field, source, author,
                 clickcount, publishdate, cover_image, detail_url)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                article_dict.get("id"),
                article_dict.get("maintitle", ""),
                article_dict.get("summary", ""),
                article_dict.get("classify", ""),
                article_dict.get("field", ""),
                article_dict.get("source", ""),
                article_dict.get("author", ""),
                article_dict.get("clickcount", 0),
                article_dict.get("publishdate", ""),
                article_dict.get("cover_image", ""),
                article_dict.get("detail_url", ""),
            ))
            conn.commit()
            return conn.total_changes > 0
        except Exception as e:
            logger.error(f"Error inserting article {article_dict.get('id')}: {e}")
            return False
        finally:
            conn.close()

    def insert_articles_batch(self, articles_list):
        """Insert multiple articles in a single transaction."""
        conn = self._get_conn()
        try:
            for article in articles_list:
                conn.execute("""
                    INSERT OR IGNORE INTO articles
                    (id, maintitle, summary, classify, field, source, author,
                     clickcount, publishdate, cover_image, detail_url)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    article.get("id"),
                    article.get("maintitle", ""),
                    article.get("summary", ""),
                    article.get("classify", ""),
                    article.get("field", ""),
                    article.get("source", ""),
                    article.get("author", ""),
                    article.get("clickcount", 0),
                    article.get("publishdate", ""),
                    article.get("cover_image", ""),
                    article.get("detail_url", ""),
                ))
            conn.commit()
            return conn.total_changes
        except Exception as e:
            logger.error(f"Error batch inserting articles: {e}")
            conn.rollback()
            return 0
        finally:
            conn.close()

    def update_article(self, article_id, fields_dict):
        """Update specific fields of an article."""
        if not fields_dict:
            return False
        set_clause = ", ".join(f"{k} = ?" for k in fields_dict.keys())
        values = list(fields_dict.values()) + [article_id]
        conn = self._get_conn()
        try:
            conn.execute(f"UPDATE articles SET {set_clause}, updated_at = CURRENT_TIMESTAMP WHERE id = ?", values)
            conn.commit()
            return conn.total_changes > 0
        except Exception as e:
            logger.error(f"Error updating article {article_id}: {e}")
            return False
        finally:
            conn.close()

    def get_articles(self, page=1, per_page=20, keyword="", classify=""):
        """Get paginated article list with optional search and filter."""
        offset = (page - 1) * per_page
        conditions = []
        params = []

        if keyword:
            conditions.append("maintitle LIKE ?")
            params.append(f"%{keyword}%")
        if classify:
            conditions.append("classify = ?")
            params.append(classify)

        where_clause = "WHERE " + " AND ".join(conditions) if conditions else ""

        conn = self._get_conn()
        try:
            # Total count
            count_row = conn.execute(f"SELECT COUNT(*) as cnt FROM articles {where_clause}", params).fetchone()
            total = count_row["cnt"] if count_row else 0

            # Paginated results
            rows = conn.execute(
                f"SELECT * FROM articles {where_clause} ORDER BY publishdate DESC LIMIT ? OFFSET ?",
                params + [per_page, offset]
            ).fetchall()

            articles = [dict(row) for row in rows]
            return articles, total
        finally:
            conn.close()

    def get_article_detail(self, article_id):
        """Get a single article by id."""
        conn = self._get_conn()
        try:
            row = conn.execute("SELECT * FROM articles WHERE id = ?", (article_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    def get_all_article_ids(self):
        """Get all article IDs."""
        conn = self._get_conn()
        try:
            rows = conn.execute("SELECT id FROM articles ORDER BY id").fetchall()
            return [row["id"] for row in rows]
        finally:
            conn.close()

    def get_uncrawled_article_ids(self):
        """Get article IDs that haven't had their details crawled yet."""
        conn = self._get_conn()
        try:
            rows = conn.execute(
                "SELECT id FROM articles WHERE crawl_status = 0 ORDER BY id"
            ).fetchall()
            return [row["id"] for row in rows]
        finally:
            conn.close()

    def get_failed_article_ids(self):
        """Get article IDs that failed during detail crawling."""
        conn = self._get_conn()
        try:
            rows = conn.execute(
                "SELECT id FROM articles WHERE crawl_status = 2 ORDER BY id"
            ).fetchall()
            return [row["id"] for row in rows]
        finally:
            conn.close()

    # ---- Image CRUD ----

    def insert_images(self, article_id, images_list):
        """Insert image records for an article. Skips if already exist."""
        conn = self._get_conn()
        try:
            for img in images_list:
                conn.execute("""
                    INSERT OR IGNORE INTO article_images (article_id, page_number, image_url)
                    VALUES (?, ?, ?)
                """, (
                    article_id,
                    img.get("page_number", 0),
                    img.get("image_url", ""),
                ))
            conn.commit()
            return conn.total_changes
        except Exception as e:
            logger.error(f"Error inserting images for article {article_id}: {e}")
            return 0
        finally:
            conn.close()

    def get_article_images(self, article_id):
        """Get all images for an article, ordered by page_number."""
        conn = self._get_conn()
        try:
            rows = conn.execute(
                "SELECT * FROM article_images WHERE article_id = ? ORDER BY page_number",
                (article_id,)
            ).fetchall()
            return [dict(row) for row in rows]
        finally:
            conn.close()

    def get_undownloaded_images(self, article_id):
        """Get images that haven't been downloaded yet for an article."""
        conn = self._get_conn()
        try:
            rows = conn.execute(
                "SELECT * FROM article_images WHERE article_id = ? AND download_status != 1 ORDER BY page_number",
                (article_id,)
            ).fetchall()
            return [dict(row) for row in rows]
        finally:
            conn.close()

    def update_image_status(self, image_id, download_status, local_path="", file_size=0):
        """Update the download status of an image by its primary key id."""
        conn = self._get_conn()
        try:
            conn.execute("""
                UPDATE article_images
                SET download_status = ?, local_path = ?, file_size = ?
                WHERE id = ?
            """, (download_status, local_path, file_size, image_id))
            conn.commit()
        except Exception as e:
            logger.error(f"Error updating image {image_id}: {e}")
        finally:
            conn.close()

    def update_image_status_by_article_page(self, article_id, page_number, download_status, local_path="", file_size=0):
        """Update the download status of an image by article_id and page_number."""
        conn = self._get_conn()
        try:
            conn.execute("""
                UPDATE article_images
                SET download_status = ?, local_path = ?, file_size = ?
                WHERE article_id = ? AND page_number = ?
            """, (download_status, local_path, file_size, article_id, page_number))
            conn.commit()
        except Exception as e:
            logger.error(f"Error updating image {article_id}/{page_number}: {e}")
        finally:
            conn.close()

    # ---- Classify ----

    def get_all_classifies(self):
        """Get all distinct classify values."""
        conn = self._get_conn()
        try:
            rows = conn.execute(
                "SELECT DISTINCT classify FROM articles WHERE classify != '' ORDER BY classify"
            ).fetchall()
            return [row["classify"] for row in rows]
        finally:
            conn.close()

    # ---- Stats ----

    def get_crawl_stats(self):
        """Get overall crawl statistics."""
        conn = self._get_conn()
        try:
            total = conn.execute("SELECT COUNT(*) as cnt FROM articles").fetchone()["cnt"]
            crawled = conn.execute("SELECT COUNT(*) as cnt FROM articles WHERE crawl_status = 1").fetchone()["cnt"]
            failed = conn.execute("SELECT COUNT(*) as cnt FROM articles WHERE crawl_status = 2").fetchone()["cnt"]
            images_downloaded = conn.execute("SELECT COUNT(*) as cnt FROM article_images WHERE download_status = 1").fetchone()["cnt"]
            total_images = conn.execute("SELECT COUNT(*) as cnt FROM article_images").fetchone()["cnt"]
            pdfs_generated = conn.execute("SELECT COUNT(*) as cnt FROM articles WHERE pdf_status = 1").fetchone()["cnt"]
            return {
                "total_articles": total,
                "crawled_details": crawled,
                "failed_details": failed,
                "total_images": total_images,
                "images_downloaded": images_downloaded,
                "pdfs_generated": pdfs_generated,
            }
        finally:
            conn.close()

    # ---- Logs ----

    def add_log(self, log_type, article_id=0, status="", message=""):
        """Add a crawl log entry."""
        conn = self._get_conn()
        try:
            conn.execute("""
                INSERT INTO crawl_logs (log_type, article_id, status, message)
                VALUES (?, ?, ?, ?)
            """, (log_type, article_id, status, message))
            conn.commit()
        except Exception as e:
            logger.error(f"Error adding log: {e}")
        finally:
            conn.close()
