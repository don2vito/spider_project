# -*- coding: utf-8 -*-
"""Crawl orchestration service."""

import logging
import threading
from typing import Optional

from models.database import Database
from crawler.dispatcher import CrawlerDispatcher
from crawler.rate_limiter import RateLimiter
from crawler.image_downloader import ImageDownloader
from config import TOTAL_PAGES

logger = logging.getLogger(__name__)


class CrawlService:
    """Orchestrates the full crawl pipeline: list → detail → images."""

    def __init__(self):
        self.db = Database()
        self.dispatcher = CrawlerDispatcher()
        self.rate_limiter = RateLimiter()
        self.image_downloader = ImageDownloader()

        # Runtime state
        self._is_running = False
        self._should_stop = False
        self._thread = None
        self._lock = threading.Lock()

        # Progress tracking
        self._progress = {
            "phase": "idle",  # idle, crawling_list, crawling_detail, downloading_images
            "current_page": 0,
            "total_pages": 0,
            "articles_found": 0,
            "details_crawled": 0,
            "images_downloaded": 0,
            "errors": 0,
        }

    @property
    def is_running(self):
        return self._is_running

    @property
    def progress(self):
        return dict(self._progress)

    def start_crawl(self, start_page=1, end_page=None, crawl_details=True, download_images=True):
        """Start crawling in a background thread."""
        with self._lock:
            if self._is_running:
                logger.warning("Crawl already running")
                return False

            self._should_stop = False
            self._is_running = True
            self._progress["phase"] = "crawling_list"
            self._progress["current_page"] = 0
            self._progress["total_pages"] = end_page or TOTAL_PAGES
            self._progress["errors"] = 0

            self._thread = threading.Thread(
                target=self._crawl_worker,
                args=(start_page, end_page, crawl_details, download_images),
                daemon=True,
            )
            self._thread.start()
            return True

    def stop_crawl(self):
        """Signal the crawl to stop."""
        self._should_stop = True
        logger.info("Stop signal sent to crawl worker")

    def _crawl_worker(self, start_page, end_page, crawl_details, download_images):
        """Main crawl worker running in background thread."""
        try:
            end_page = end_page or TOTAL_PAGES

            # Phase 1: Crawl list pages
            self._progress["phase"] = "crawling_list"
            for page in range(start_page, end_page + 1):
                if self._should_stop:
                    logger.info("Crawl stopped by user during list phase")
                    break

                self._progress["current_page"] = page
                self.rate_limiter.wait()

                articles = self.dispatcher.fetch_list_page(page)
                if articles:
                    inserted = self.db.insert_articles_batch(articles)
                    self._progress["articles_found"] += len(articles)
                    self.db.add_log("list", status="success",
                                    message=f"Page {page}: {len(articles)} articles, {inserted} new")
                else:
                    self._progress["errors"] += 1
                    self.db.add_log("list", status="error",
                                    message=f"Page {page}: no data retrieved")

            # Phase 2: Crawl detail pages
            if crawl_details and not self._should_stop:
                self._progress["phase"] = "crawling_detail"
                uncrawled_ids = self.db.get_uncrawled_article_ids()
                self._progress["details_crawled"] = 0

                for i, aid in enumerate(uncrawled_ids):
                    if self._should_stop:
                        logger.info("Crawl stopped by user during detail phase")
                        break

                    self.rate_limiter.wait()
                    detail = self.dispatcher.fetch_detail_page(aid)

                    if detail:
                        images = detail.get("images", [])
                        self.db.insert_images(aid, images)
                        
                        # Set cover_image from first image
                        cover_image = ""
                        if images and len(images) > 0:
                            cover_image = images[0].get("image_url", "")
                        
                        self.db.update_article(aid, {
                            "crawl_status": 1,
                            "image_count": len(images),
                            "summary": detail.get("summary", ""),
                            "classify": detail.get("classify", ""),
                            "field": detail.get("field", ""),
                            "cover_image": cover_image,
                        })
                        self._progress["details_crawled"] += 1
                        self.db.add_log("detail", article_id=aid, status="success",
                                        message=f"{len(images)} images found")
                    else:
                        self.db.update_article(aid, {"crawl_status": 2})
                        self._progress["errors"] += 1
                        self.db.add_log("detail", article_id=aid, status="error",
                                        message="Failed to fetch detail")

            # Phase 3: Download images
            if download_images and not self._should_stop:
                self._progress["phase"] = "downloading_images"
                self._progress["images_downloaded"] = 0

                # Get all articles with images not yet downloaded
                all_ids = self.db.get_all_article_ids()
                for aid in all_ids:
                    if self._should_stop:
                        break

                    undownloaded = self.db.get_undownloaded_images(aid)
                    if not undownloaded:
                        continue

                    # Small delay between articles
                    self.rate_limiter.wait()

                    images_to_download = [
                        {"page_number": img["page_number"], "image_url": img["image_url"]}
                        for img in undownloaded
                    ]

                    results = self.image_downloader.download_article_images(aid, images_to_download)

                    downloaded_count = 0
                    for result in results:
                        if result["status"] == "success":
                            self.db.update_image_status_by_article_page(
                                aid,
                                result["page_number"],
                                1,
                                result["local_path"],
                                result.get("file_size", 0),
                            )
                            downloaded_count += 1
                        else:
                            self._progress["errors"] += 1

                    self._progress["images_downloaded"] += downloaded_count

                    if downloaded_count > 0:
                        self.db.add_log("image", article_id=aid, status="success",
                                        message=f"{downloaded_count} images downloaded")

            self._progress["phase"] = "idle"
            logger.info("Crawl completed")

        except Exception as e:
            logger.error(f"Crawl worker error: {e}", exc_info=True)
            self._progress["phase"] = "idle"
        finally:
            self._is_running = False

    def get_status(self):
        """Get current crawl status and statistics."""
        stats = self.db.get_crawl_stats()
        return {
            "is_running": self._is_running,
            "progress": self._progress,
            "stats": stats,
        }

    def retry_failed(self):
        """Retry crawling failed articles."""
        failed_ids = self.db.get_failed_article_ids()
        if not failed_ids:
            return False

        self._should_stop = False
        self._is_running = True
        self._progress["phase"] = "crawling_detail"
        self._progress["errors"] = 0

        self._thread = threading.Thread(
            target=self._retry_worker,
            args=(failed_ids,),
            daemon=True,
        )
        self._thread.start()
        return True

    def _retry_worker(self, failed_ids):
        """Worker for retrying failed articles."""
        try:
            for aid in failed_ids:
                if self._should_stop:
                    break

                self.rate_limiter.wait()
                detail = self.dispatcher.fetch_detail_page(aid)

                if detail:
                    images = detail.get("images", [])
                    self.db.insert_images(aid, images)
                    self.db.update_article(aid, {
                        "crawl_status": 1,
                        "image_count": len(images),
                    })
                    self.db.add_log("detail", article_id=aid, status="success",
                                    message=f"Retry: {len(images)} images found")
                else:
                    self._progress["errors"] += 1
                    self.db.add_log("detail", article_id=aid, status="error",
                                    message=f"Retry failed for article {aid}")

        except Exception as e:
            logger.error(f"Retry worker error: {e}")
        finally:
            self._is_running = False
            self._progress["phase"] = "idle"
