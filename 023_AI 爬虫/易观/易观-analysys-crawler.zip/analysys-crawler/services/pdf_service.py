# -*- coding: utf-8 -*-
"""PDF generation service - convert report images to PDF."""

import os
import re
import logging
from typing import Optional

from config import IMAGE_DIR, PDF_DIR

logger = logging.getLogger(__name__)


def sanitize_filename(name: str, max_length: int = 100) -> str:
    """Sanitize a string for use as a filename.

    Removes illegal characters and truncates if too long.
    """
    # Remove illegal characters for Windows/Linux/Mac
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    # Remove leading/trailing spaces and dots
    name = name.strip(' .')
    # Replace multiple spaces with single space
    name = re.sub(r'\s+', ' ', name)
    # Truncate
    if len(name) > max_length:
        name = name[:max_length].rstrip(' .')
    return name or "unnamed_report"


class PDFService:
    """Generate PDF files from downloaded report images."""

    def generate_pdf(self, article_id: int, report_title: str = "") -> str:
        """Generate a PDF from article images.

        Args:
            article_id: Article ID.
            report_title: Report title (used for filename).

        Returns:
            Path to the generated PDF file.

        Raises:
            FileNotFoundError: If no images found for the article.
            Exception: If PDF generation fails.
        """
        article_dir = os.path.join(IMAGE_DIR, str(article_id))

        if not os.path.exists(article_dir):
            raise FileNotFoundError(f"No image directory found for article {article_id}")

        # Collect and sort image files
        image_files = sorted([
            os.path.join(article_dir, f)
            for f in os.listdir(article_dir)
            if f.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'))
        ])

        if not image_files:
            raise FileNotFoundError(f"No images found for article {article_id}")

        # Generate PDF filename
        safe_title = sanitize_filename(report_title) if report_title else f"report_{article_id}"
        pdf_filename = f"{safe_title}.pdf"
        pdf_path = os.path.join(PDF_DIR, pdf_filename)

        # Skip if already exists
        if os.path.exists(pdf_path) and os.path.getsize(pdf_path) > 0:
            logger.info(f"PDF already exists: {pdf_path}")
            return pdf_path

        # Generate PDF using img2pdf
        try:
            import img2pdf
            with open(pdf_path, "wb") as f:
                f.write(img2pdf.convert(image_files))
            logger.info(f"PDF generated: {pdf_path} ({len(image_files)} pages)")
            return pdf_path
        except ImportError:
            logger.warning("img2pdf not available, falling back to Pillow")
            return self._generate_pdf_with_pillow(image_files, pdf_path)
        except Exception as e:
            logger.error(f"img2pdf failed for article {article_id}: {e}")
            # Fallback to Pillow
            try:
                return self._generate_pdf_with_pillow(image_files, pdf_path)
            except Exception as e2:
                logger.error(f"Pillow fallback also failed: {e2}")
                raise

    def _generate_pdf_with_pillow(self, image_files: list, pdf_path: str) -> str:
        """Generate PDF using Pillow as fallback."""
        from PIL import Image

        imgs = []
        first_img = None
        for img_path in image_files:
            try:
                img = Image.open(img_path)
                if img.mode == 'RGBA':
                    img = img.convert('RGB')
                elif img.mode != 'RGB':
                    img = img.convert('RGB')
                if first_img is None:
                    first_img = img
                else:
                    imgs.append(img)
            except Exception as e:
                logger.warning(f"Failed to open image {img_path}: {e}")
                continue

        if first_img is None:
            raise FileNotFoundError("No valid images to convert")

        if imgs:
            first_img.save(pdf_path, "PDF", save_all=True, append_images=imgs, resolution=100)
        else:
            first_img.save(pdf_path, "PDF", resolution=100)

        logger.info(f"PDF generated with Pillow: {pdf_path}")
        return pdf_path

    def generate_batch_pdfs(self, articles: list) -> dict:
        """Generate PDFs for multiple articles.

        Args:
            articles: List of dicts with 'id' and 'maintitle' keys.

        Returns:
            Dict mapping article_id to {'status': 'success'/'error', 'path': str, 'error': str}.
        """
        results = {}
        for article in articles:
            aid = article.get("id")
            title = article.get("maintitle", "")
            try:
                pdf_path = self.generate_pdf(aid, title)
                results[aid] = {"status": "success", "path": pdf_path}
            except Exception as e:
                results[aid] = {"status": "error", "error": str(e)}
        return results

    def get_pdf_path(self, article_id: int, report_title: str = "") -> Optional[str]:
        """Get the PDF path if it already exists, without regenerating."""
        safe_title = sanitize_filename(report_title) if report_title else f"report_{article_id}"
        pdf_filename = f"{safe_title}.pdf"
        pdf_path = os.path.join(PDF_DIR, pdf_filename)

        if os.path.exists(pdf_path) and os.path.getsize(pdf_path) > 0:
            return pdf_path
        return None
