@echo off
chcp 65001 >nul 2>&1
title Analysys Report Crawler

echo ========================================
echo   Analysys Report Crawler - Local Server
echo ========================================
echo.

:: Check Python installation
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed. Please install Python 3.8+ first.
    echo Download: https://www.python.org/downloads/
    pause
    exit /b 1
)

:: Create virtual environment if not exists
if not exist "venv" (
    echo [INIT] Creating virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
    call venv\Scripts\activate.bat
    echo [INIT] Installing dependencies...
    pip install -r requirements.txt --break-system-packages >nul 2>&1
    if errorlevel 1 (
        pip install -r requirements.txt >nul 2>&1
    )
    echo [INIT] Setup complete.
    echo.
) else (
    call venv\Scripts\activate.bat
)

:: Create data directories
if not exist "data\images" mkdir data\images
if not exist "data\pdfs" mkdir data\pdfs
if not exist "logs" mkdir logs

:: Start Flask server
echo.
echo [START] Starting server...
echo [URL]   http://127.0.0.1:5000
echo.
echo Press Ctrl+C to stop the server.
echo.

python app.py

pause
