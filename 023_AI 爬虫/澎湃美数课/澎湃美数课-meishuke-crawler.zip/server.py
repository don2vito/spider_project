"""
澎湃新闻「美数课」数据报告爬取系统 - 代理服务器
三层分级爬取策略：API接口优先 → HTML解析备用 → Playwright兜底
"""

import os
import re
import json
import time
import random
import shutil
import tempfile
import zipfile
import traceback
from datetime import datetime
from io import BytesIO

from flask import Flask, jsonify, send_file, request, send_from_directory
from flask_cors import CORS

import requests
from bs4 import BeautifulSoup
from PIL import Image
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

# ============================================================
# Configuration
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
PDF_DIR = os.path.join(DATA_DIR, "pdfs")
REPORTS_FILE = os.path.join(DATA_DIR, "reports.json")
NODE_ID = "25635"
LIST_API_URL = "https://api.thepaper.cn/contentapi/nodeCont/getByNodeIdPortal"
DETAIL_URL_TEMPLATE = "https://www.thepaper.cn/newsDetail_forward_{}"
PAGE_SIZE = 20
REQUEST_DELAY = 2.0  # seconds between requests
MAX_RETRIES = 3  # max retries per page

# Multiple User-Agents for rotation
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
]

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PDF_DIR, exist_ok=True)

app = Flask(__name__, static_folder=BASE_DIR)
CORS(app)

# Global session for connection pooling
session = requests.Session()

def get_headers():
    """Get headers with random User-Agent."""
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Referer": "https://www.thepaper.cn/",
        "Origin": "https://www.thepaper.cn",
        "Connection": "keep-alive",
    }


# ============================================================
# Data Persistence
# ============================================================
def load_reports():
    """Load cached reports from JSON file."""
    if os.path.exists(REPORTS_FILE):
        try:
            with open(REPORTS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {"lastUpdate": None, "reports": []}


def save_reports(data):
    """Save reports to JSON file."""
    data["lastUpdate"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    with open(REPORTS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ============================================================
# Layer 1: API-based fetching (primary)
# ============================================================
def fetch_via_api(start_time=0):
    """
    Fetch reports via the Paper.cn API endpoint.
    Returns (list_of_reports, next_start_time, has_more).
    """
    payload = {
        "nodeId": NODE_ID,
        "excludeContIds": [],
        "pageSize": PAGE_SIZE,
    }
    if start_time > 0:
        payload["startTime"] = start_time

    for attempt in range(MAX_RETRIES):
        try:
            resp = session.post(
                LIST_API_URL, 
                json=payload, 
                headers=get_headers(),
                timeout=20
            )
            
            # Check for WAF/blocking
            if resp.status_code == 403 or resp.status_code == 401:
                print(f"[API] WAF blocked (attempt {attempt + 1}/{MAX_RETRIES})")
                if attempt < MAX_RETRIES - 1:
                    time.sleep(3 + random.uniform(1, 3))  # Wait before retry
                    continue
                return [], 0, False
                
            resp.raise_for_status()
            data = resp.json()

            if data.get("code") == 200 and data.get("data"):
                result = data["data"]
                reports = []
                for item in result.get("list", []):
                    cont_id = str(item.get("contId", ""))
                    if not cont_id:
                        continue
                    reports.append({
                        "contId": cont_id,
                        "name": item.get("name", "").strip(),
                        "smallPic": item.get("smallPic", ""),
                        "pic": item.get("pic", ""),
                        "pubTimeNew": item.get("pubTimeNew", ""),
                        "pubTimeLong": item.get("pubTimeLong", 0),
                        "interactionNum": item.get("interactionNum", "0"),
                        "contType": item.get("contType", 0),
                        "detailUrl": DETAIL_URL_TEMPLATE.format(cont_id),
                        "pdfGenerated": False,
                    })

                next_start = result.get("startTime", 0)
                has_next = result.get("hasNext", False)
                return reports, next_start, has_next
            else:
                print(f"[API] Unexpected response: code={data.get('code')}, msg={data.get('msg')}")
                return [], 0, False
        except Exception as e:
            print(f"[API] Request failed (attempt {attempt + 1}/{MAX_RETRIES}): {e}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(2 + random.uniform(1, 2))
                continue
            return [], 0, False
    
    return [], 0, False


# ============================================================
# Layer 2: HTML parsing (fallback)
# ============================================================
def fetch_via_html():
    """
    Fetch reports by parsing the SSR HTML page's __NEXT_DATA__ JSON.
    Returns list of reports (first page only).
    """
    try:
        resp = session.get(
            f"https://www.thepaper.cn/list_{NODE_ID}",
            headers={**get_headers(), "Accept": "text/html"},
            timeout=20,
        )
        resp.raise_for_status()

        match = re.search(
            r'<script\s+id="__NEXT_DATA__"\s+type="application/json">(.*?)</script>',
            resp.text,
            re.DOTALL,
        )
        if not match:
            print("[HTML] __NEXT_DATA__ not found")
            return []

        next_data = json.loads(match.group(1))
        page_props = next_data.get("props", {}).get("pageProps", {}).get("data", {})
        items = page_props.get("list", [])

        reports = []
        for item in items:
            cont_id = str(item.get("contId", ""))
            if not cont_id:
                continue
            reports.append({
                "contId": cont_id,
                "name": item.get("name", "").strip(),
                "smallPic": item.get("smallPic", ""),
                "pic": item.get("pic", ""),
                "pubTimeNew": item.get("pubTimeNew", ""),
                "pubTimeLong": item.get("pubTimeLong", 0),
                "interactionNum": item.get("interactionNum", "0"),
                "contType": item.get("contType", 0),
                "detailUrl": DETAIL_URL_TEMPLATE.format(cont_id),
                "pdfGenerated": False,
            })
        return reports
    except Exception as e:
        print(f"[HTML] Parse failed: {e}")
        return []


# ============================================================
# Fetch all reports (with layer fallback)
# ============================================================
def fetch_all_reports():
    """
    Fetch all reports using layered strategy.
    Layer 1: API pagination (primary)
    Layer 2: HTML parsing (fallback)
    Returns list of new reports.
    """
    cached = load_reports()
    existing_ids = {r["contId"] for r in cached["reports"]}

    all_new = []

    # --- Layer 1: API ---
    print("[Fetch] Trying Layer 1: API endpoint with full pagination...")
    start_time = 0
    page = 0
    total_fetched = 0
    api_success = False

    while True:
        page += 1
        print(f"[Fetch] API page {page}, startTime={start_time}")
        reports, next_start, has_next = fetch_via_api(start_time)

        if not reports:
            if page == 1:
                # API failed on first page, try Layer 2
                print("[Fetch] Layer 1 failed (empty response), falling back to Layer 2...")
                break
            else:
                # No more data
                print(f"[Fetch] No more data after {total_fetched} items")
                break

        api_success = True
        page_count = len(reports)
        total_fetched += page_count
        
        for r in reports:
            if r["contId"] not in existing_ids:
                all_new.append(r)
                existing_ids.add(r["contId"])

        print(f"[Fetch] Page {page}: got {page_count} items (total fetched: {total_fetched}), hasNext={has_next}")

        if not has_next:
            print(f"[Fetch] Reached last page, total: {total_fetched} items")
            break

        start_time = next_start
        time.sleep(REQUEST_DELAY)

    if not api_success:
        # --- Layer 2: HTML parsing ---
        print("[Fetch] Trying Layer 2: HTML parsing...")
        reports = fetch_via_html()
        for r in reports:
            if r["contId"] not in existing_ids:
                all_new.append(r)
                existing_ids.add(r["contId"])

    # Merge and save
    if all_new:
        # Merge: new reports go to front, keep existing
        merged = all_new + cached["reports"]
        # Deduplicate by contId (keep first occurrence)
        seen = set()
        unique = []
        for r in merged:
            if r["contId"] not in seen:
                seen.add(r["contId"])
                unique.append(r)
        # Sort by pubTimeLong descending
        unique.sort(key=lambda x: x.get("pubTimeLong", 0), reverse=True)
        save_reports({"reports": unique})
        print(f"[Fetch] Added {len(all_new)} new reports, total: {len(unique)}")
    else:
        print("[Fetch] No new reports found")

    return all_new


# ============================================================
# Detail page image extraction
# ============================================================
def extract_images_from_detail(cont_id):
    """
    Extract image URLs from a report detail page.
    Strategy: Parse __NEXT_DATA__ JSON first, fallback to HTML parsing.
    Returns list of image URLs in order.
    """
    url = DETAIL_URL_TEMPLATE.format(cont_id)
    print(f"[Images] Fetching detail page: {url}")

    try:
        resp = session.get(url, headers={**get_headers(), "Accept": "text/html"}, timeout=20)
        resp.raise_for_status()
        html = resp.text
    except Exception as e:
        print(f"[Images] Failed to fetch detail page: {e}")
        return []

    image_urls = []

    # Strategy 1: Parse __NEXT_DATA__ JSON
    try:
        match = re.search(
            r'<script\s+id="__NEXT_DATA__"\s+type="application/json">(.*?)</script>',
            html,
            re.DOTALL,
        )
        if match:
            next_data = json.loads(match.group(1))
            content_detail = (
                next_data.get("props", {})
                .get("pageProps", {})
                .get("detailData", {})
                .get("contentDetail", {})
            )

            # Try images array first
            images = content_detail.get("images", [])
            if images:
                for img in images:
                    img_url = img.get("url") or img.get("src", "")
                    if img_url:
                        # Remove OSS resize params to get original
                        img_url = re.sub(r'\?x-oss-process=.*$', '', img_url)
                        image_urls.append(img_url)
                print(f"[Images] Found {len(image_urls)} images from __NEXT_DATA__.images")
                return image_urls

            # Fallback: parse content HTML for img tags
            content_html = content_detail.get("content", "")
            if content_html:
                soup = BeautifulSoup(content_html, "html.parser")
                for img_tag in soup.find_all("img"):
                    img_url = img_tag.get("data-src") or img_tag.get("src", "")
                    if img_url and not img_url.startswith("data:"):
                        img_url = re.sub(r'\?x-oss-process=.*$', '', img_url)
                        image_urls.append(img_url)
                if image_urls:
                    print(f"[Images] Found {len(image_urls)} images from content HTML")
                    return image_urls
    except Exception as e:
        print(f"[Images] __NEXT_DATA__ parse failed: {e}")

    # Strategy 2: Parse HTML DOM directly
    try:
        soup = BeautifulSoup(html, "html.parser")
        content_wrap = soup.find("div", class_=re.compile(r"cententWrap"))
        if content_wrap:
            for img_tag in content_wrap.find_all("img"):
                img_url = img_tag.get("data-src") or img_tag.get("src", "")
                if img_url and not img_url.startswith("data:"):
                    img_url = re.sub(r'\?x-oss-process=.*$', '', img_url)
                    image_urls.append(img_url)
            if image_urls:
                print(f"[Images] Found {len(image_urls)} images from DOM parsing")
                return image_urls
    except Exception as e:
        print(f"[Images] DOM parse failed: {e}")

    print("[Images] No images found")
    return []


# ============================================================
# PDF Generation
# ============================================================
def sanitize_filename(name):
    """Remove illegal characters from filename."""
    name = re.sub(r'[\\/:*?"<>|]', '_', name)
    name = re.sub(r'\s+', ' ', name).strip()
    if len(name) > 150:
        name = name[:150]
    return name


def download_image(url, timeout=15):
    """Download an image and return as PIL Image object."""
    try:
        headers = {
            "User-Agent": random.choice(USER_AGENTS),
            "Referer": "https://www.thepaper.cn/",
        }
        resp = session.get(url, headers=headers, timeout=timeout, stream=True)
        resp.raise_for_status()
        img = Image.open(BytesIO(resp.content))
        # Convert to RGB if necessary (for PNG with alpha, etc.)
        if img.mode in ("RGBA", "P", "LA"):
            img = img.convert("RGB")
        return img
    except Exception as e:
        print(f"[PDF] Failed to download image {url}: {e}")
        return None


def generate_pdf(cont_id, report_name):
    """
    Generate a PDF from report images.
    Returns the file path of the generated PDF.
    """
    pdf_filename = sanitize_filename(report_name) + ".pdf"
    pdf_path = os.path.join(PDF_DIR, pdf_filename)

    # Check cache
    if os.path.exists(pdf_path):
        print(f"[PDF] Using cached: {pdf_filename}")
        return pdf_path

    # Extract image URLs
    image_urls = extract_images_from_detail(cont_id)
    if not image_urls:
        print(f"[PDF] No images found for report {cont_id}")
        return None

    print(f"[PDF] Generating PDF for '{report_name}' with {len(image_urls)} images...")

    # Download images
    images = []
    for i, url in enumerate(image_urls):
        print(f"[PDF] Downloading image {i+1}/{len(image_urls)}...")
        img = download_image(url)
        if img:
            images.append(img)
        time.sleep(0.3)  # Small delay between image downloads

    if not images:
        print(f"[PDF] No images could be downloaded for report {cont_id}")
        return None

    # Create PDF
    try:
        c = canvas.Canvas(pdf_path, pagesize=A4)
        page_width, page_height = A4
        margin = 15 * mm

        for img in images:
            # Calculate image dimensions to fit page
            img_width, img_height = img.size
            max_width = page_width - 2 * margin
            max_height = page_height - 2 * margin

            # Scale to fit
            scale_w = max_width / img_width
            scale_h = max_height / img_height
            scale = min(scale_w, scale_h, 1.0)  # Don't upscale

            draw_width = img_width * scale
            draw_height = img_height * scale

            # Center on page
            x = (page_width - draw_width) / 2
            y = (page_height - draw_height) / 2

            # Draw image
            img_buffer = BytesIO()
            img.save(img_buffer, format="JPEG", quality=92)
            img_buffer.seek(0)
            c.drawImage(ImageReader(img_buffer), x, y, draw_width, draw_height)
            c.showPage()

        c.save()
        print(f"[PDF] Generated: {pdf_path}")
        return pdf_path
    except Exception as e:
        print(f"[PDF] Failed to generate PDF: {e}")
        traceback.print_exc()
        # Clean up partial file
        if os.path.exists(pdf_path):
            os.remove(pdf_path)
        return None


def generate_zip(cont_ids, reports_data):
    """
    Generate a ZIP file containing PDFs for the given cont_ids.
    Returns the file path of the ZIP.
    """
    zip_buffer = BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for cont_id in cont_ids:
            # Find report name
            report = next((r for r in reports_data if r["contId"] == cont_id), None)
            if not report:
                continue
            report_name = report["name"]
            pdf_path = generate_pdf(cont_id, report_name)
            if pdf_path and os.path.exists(pdf_path):
                pdf_filename = sanitize_filename(report_name) + ".pdf"
                zf.write(pdf_path, pdf_filename)
            else:
                print(f"[ZIP] Skipped {cont_id} - PDF generation failed")

    zip_buffer.seek(0)
    return zip_buffer


# ============================================================
# Flask Routes
# ============================================================
@app.route("/")
def index():
    """Serve the frontend page."""
    return send_from_directory(BASE_DIR, "index.html")


@app.route("/api/reports")
def get_reports():
    """Return cached reports."""
    data = load_reports()
    return jsonify({
        "success": True,
        "total": len(data["reports"]),
        "lastUpdate": data["lastUpdate"],
        "reports": data["reports"],
    })


@app.route("/api/fetch", methods=["POST"])
def fetch_reports():
    """Trigger incremental fetch."""
    try:
        new_reports = fetch_all_reports()
        data = load_reports()
        return jsonify({
            "success": True,
            "newCount": len(new_reports),
            "total": len(data["reports"]),
            "lastUpdate": data["lastUpdate"],
            "newReports": new_reports,
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/download/<cont_id>")
def download_single(cont_id):
    """Generate and download a single report PDF."""
    data = load_reports()
    report = next((r for r in data["reports"] if r["contId"] == cont_id), None)
    if not report:
        return jsonify({"success": False, "error": "Report not found"}), 404

    pdf_path = generate_pdf(cont_id, report["name"])
    if not pdf_path:
        return jsonify({"success": False, "error": "Failed to generate PDF - no images found"}), 404

    pdf_filename = sanitize_filename(report["name"]) + ".pdf"
    return send_file(
        pdf_path,
        as_attachment=True,
        download_name=pdf_filename,
        mimetype="application/pdf",
    )


@app.route("/api/batch-download", methods=["POST"])
def batch_download():
    """Batch download selected reports as ZIP."""
    body = request.get_json(force=True)
    cont_ids = body.get("contIds", [])
    if not cont_ids:
        return jsonify({"success": False, "error": "No report IDs provided"}), 400

    data = load_reports()
    zip_buffer = generate_zip(cont_ids, data["reports"])

    if zip_buffer.getbuffer().nbytes == 0:
        return jsonify({"success": False, "error": "No PDFs could be generated"}), 404

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"meishuke_reports_{timestamp}.zip"
    return send_file(
        BytesIO(zip_buffer.getvalue()),
        as_attachment=True,
        download_name=zip_filename,
        mimetype="application/zip",
    )


@app.route("/api/download-all")
def download_all():
    """Download all reports as ZIP."""
    data = load_reports()
    cont_ids = [r["contId"] for r in data["reports"]]
    if not cont_ids:
        return jsonify({"success": False, "error": "No reports available"}), 404

    zip_buffer = generate_zip(cont_ids, data["reports"])

    if zip_buffer.getbuffer().nbytes == 0:
        return jsonify({"success": False, "error": "No PDFs could be generated"}), 404

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"meishuke_all_reports_{timestamp}.zip"
    return send_file(
        BytesIO(zip_buffer.getvalue()),
        as_attachment=True,
        download_name=zip_filename,
        mimetype="application/zip",
    )


@app.route("/api/fetch-status")
def fetch_status():
    """Check if reports data exists."""
    data = load_reports()
    return jsonify({
        "hasData": len(data["reports"]) > 0,
        "total": len(data["reports"]),
        "lastUpdate": data["lastUpdate"],
    })


@app.route("/api/proxy-image")
def proxy_image():
    """Proxy image requests to bypass CDN Referer checks."""
    url = request.args.get("url", "")
    if not url:
        return jsonify({"error": "Missing url parameter"}), 400

    try:
        headers = {
            "User-Agent": random.choice(USER_AGENTS),
            "Referer": "https://www.thepaper.cn/",
            "Accept": "image/webp,image/apng,image/*,*/*;q=0.8",
        }
        resp = session.get(url, headers=headers, timeout=10, stream=True)
        resp.raise_for_status()

        content_type = resp.headers.get("Content-Type", "image/jpeg")
        return send_file(
            BytesIO(resp.content),
            mimetype=content_type,
            max_age=86400,  # Cache for 24h
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 502


# ============================================================
# Main
# ============================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  澎湃美数课 · 数据报告爬取系统")
    print("  MeiShuKe Report Crawler System")
    print("=" * 60)
    print(f"  Data directory: {DATA_DIR}")
    print(f"  PDF directory:  {PDF_DIR}")
    print(f"  Access URL:     http://localhost:5000")
    print("=" * 60)

    # Pre-load data check
    data = load_reports()
    if data["reports"]:
        print(f"  Cached reports: {len(data['reports'])}")
        print(f"  Last update:    {data['lastUpdate']}")
    else:
        print("  No cached data. Open the browser to start fetching.")

    print("=" * 60)
    print()

    app.run(host="0.0.0.0", port=5000, debug=False)
