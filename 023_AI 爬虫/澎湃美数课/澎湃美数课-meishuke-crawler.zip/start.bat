@echo off
chcp 65001 >nul 2>&1
title MeiShuKe Report Crawler

echo ============================================
echo   MeiShuKe Report Crawler System
echo   Starting...
echo ============================================
echo.

:: Check Python installation
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo Please install Python 3.8+ from https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)

echo [INFO] Python found:
python --version
echo.

:: Install dependencies
echo [INFO] Installing dependencies...
pip install -r requirements.txt --quiet
echo [INFO] Dependencies installed.
echo.

:: Create data directories
if not exist "data" mkdir data
if not exist "data\pdfs" mkdir data\pdfs

:: Start server and open browser
echo [INFO] Starting server on http://localhost:5000
echo [INFO] Opening browser...
start http://localhost:5000
echo.

python server.py

pause
