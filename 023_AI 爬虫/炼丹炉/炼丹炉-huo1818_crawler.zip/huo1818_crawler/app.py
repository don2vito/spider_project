#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
炼丹炉行业报告爬虫 - Flask Web服务
"""

import os
import json
import zipfile
import io
import re
from datetime import datetime
from urllib.parse import urlparse

from flask import Flask, render_template, jsonify, request, send_file, Response
import requests

from crawler import Huo1818Crawler

# 创建Flask应用
app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False

# 初始化爬虫
crawler = Huo1818Crawler(data_dir="data")

# 下载目录
DOWNLOAD_DIR = os.path.join(os.path.dirname(__file__), "static", "downloads")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)


def sanitize_filename(filename: str) -> str:
    """清理文件名中的非法字符"""
    # 移除或替换Windows文件名中的非法字符
    filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
    # 移除控制字符
    filename = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', filename)
    # 限制长度
    if len(filename) > 200:
        filename = filename[:200]
    return filename.strip()


def encode_filename_for_header(filename: str) -> str:
    """
    将文件名编码为HTTP响应头可用的格式
    使用RFC 5987编码（UTF-8 with percent-encoding）
    """
    # 对于ASCII字符，直接使用
    # 对于非ASCII字符（如中文），使用RFC 5987编码
    try:
        # 尝试使用ASCII编码
        filename.encode('ascii')
        return f'filename="{filename}"'
    except UnicodeEncodeError:
        # 包含非ASCII字符，使用RFC 5987编码
        from urllib.parse import quote
        encoded = quote(filename, safe='')
        return f"filename*=UTF-8''{encoded}"


@app.route('/')
def index():
    """主页面"""
    return render_template('index.html')


# ==================== API接口 ====================

@app.route('/api/reports')
def get_reports():
    """获取所有报告列表"""
    try:
        reports = crawler.get_reports()
        return jsonify({
            "success": True,
            "data": reports,
            "total": len(reports)
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@app.route('/api/reports/refresh', methods=['POST'])
def refresh_reports():
    """手动刷新数据"""
    try:
        result = crawler.crawl_all()
        return jsonify(result)
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@app.route('/api/report/<report_id>')
def get_report_detail(report_id):
    """获取单个报告详情"""
    try:
        report = crawler.get_report_by_id(report_id)
        if report:
            return jsonify({
                "success": True,
                "data": report
            })
        else:
            return jsonify({
                "success": False,
                "error": "报告不存在"
            }), 404
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


# ==================== 下载接口 ====================

@app.route('/api/download/<report_id>')
def download_single(report_id):
    """下载单个PDF"""
    try:
        report = crawler.get_report_by_id(report_id)
        if not report:
            return jsonify({
                "success": False,
                "error": "报告不存在"
            }), 404
        
        pdf_url = report.get('pdfUrl')
        if not pdf_url:
            return jsonify({
                "success": False,
                "error": "PDF链接不存在"
            }), 404
        
        # 下载PDF
        response = requests.get(pdf_url, timeout=30, stream=True)
        response.raise_for_status()
        
        # 生成文件名
        title = report.get('title', 'report')
        filename = sanitize_filename(f"{title}.pdf")
        
        # 编码文件名以支持中文
        content_disposition = encode_filename_for_header(filename)
        
        return Response(
            response.iter_content(chunk_size=8192),
            headers={
                'Content-Type': 'application/pdf',
                'Content-Disposition': f'attachment; {content_disposition}'
            }
        )
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@app.route('/api/download/batch', methods=['POST'])
def download_batch():
    """批量下载PDF，返回ZIP文件"""
    try:
        data = request.get_json()
        if not data or 'ids' not in data:
            return jsonify({
                "success": False,
                "error": "缺少ids参数"
            }), 400
        
        report_ids = data['ids']
        if not isinstance(report_ids, list) or len(report_ids) == 0:
            return jsonify({
                "success": False,
                "error": "ids必须是非空数组"
            }), 400
        
        # 限制批量下载数量
        if len(report_ids) > 50:
            return jsonify({
                "success": False,
                "error": "单次最多下载50个文件"
            }), 400
        
        # 创建内存中的ZIP文件
        memory_file = io.BytesIO()
        
        with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zf:
            for report_id in report_ids:
                report = crawler.get_report_by_id(report_id)
                if not report:
                    continue
                
                pdf_url = report.get('pdfUrl')
                if not pdf_url:
                    continue
                
                try:
                    # 下载PDF
                    response = requests.get(pdf_url, timeout=30)
                    response.raise_for_status()
                    
                    # 生成文件名
                    title = report.get('title', report_id)
                    filename = sanitize_filename(f"{title}.pdf")
                    
                    # 添加到ZIP
                    zf.writestr(filename, response.content)
                    
                except Exception as e:
                    print(f"下载失败 {report_id}: {e}")
                    continue
        
        memory_file.seek(0)
        
        # 生成ZIP文件名
        zip_filename = f"reports_batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
        content_disposition = encode_filename_for_header(zip_filename)
        
        return Response(
            memory_file.getvalue(),
            headers={
                'Content-Type': 'application/zip',
                'Content-Disposition': f'attachment; {content_disposition}'
            }
        )
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@app.route('/api/download/all')
def download_all():
    """下载所有PDF，返回ZIP文件"""
    try:
        reports = crawler.get_reports()
        
        if not reports:
            return jsonify({
                "success": False,
                "error": "没有可下载的报告"
            }), 404
        
        # 创建内存中的ZIP文件
        memory_file = io.BytesIO()
        
        with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zf:
            for report in reports:
                pdf_url = report.get('pdfUrl')
                if not pdf_url:
                    continue
                
                try:
                    # 下载PDF
                    response = requests.get(pdf_url, timeout=30)
                    response.raise_for_status()
                    
                    # 生成文件名
                    title = report.get('title', report.get('reportId', 'report'))
                    filename = sanitize_filename(f"{title}.pdf")
                    
                    # 添加到ZIP
                    zf.writestr(filename, response.content)
                    
                except Exception as e:
                    print(f"下载失败 {report.get('reportId')}: {e}")
                    continue
        
        memory_file.seek(0)
        
        # 生成ZIP文件名
        zip_filename = f"reports_all_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
        content_disposition = encode_filename_for_header(zip_filename)
        
        return Response(
            memory_file.getvalue(),
            headers={
                'Content-Type': 'application/zip',
                'Content-Disposition': f'attachment; {content_disposition}'
            }
        )
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


# ==================== 统计接口 ====================

@app.route('/api/stats')
def get_stats():
    """获取统计数据"""
    try:
        reports = crawler.get_reports()
        
        # 计算统计数据
        total_reports = len(reports)
        total_views = sum(r.get('viewCount', 0) for r in reports)
        
        # 按时间统计
        time_stats = {}
        for report in reports:
            publish_time = report.get('publishTime', '')
            if publish_time:
                year_month = publish_time[:7]  # YYYY-MM
                time_stats[year_month] = time_stats.get(year_month, 0) + 1
        
        return jsonify({
            "success": True,
            "data": {
                "totalReports": total_reports,
                "totalViews": total_views,
                "timeDistribution": time_stats
            }
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


# ==================== 错误处理 ====================

@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "success": False,
        "error": "接口不存在"
    }), 404


@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        "success": False,
        "error": "服务器内部错误"
    }), 500


# ==================== 启动 ====================

if __name__ == '__main__':
    print("=" * 50)
    print("炼丹炉行业报告爬虫服务")
    print("=" * 50)
    print(f"数据文件: {crawler.data_file}")
    print(f"下载目录: {DOWNLOAD_DIR}")
    print("=" * 50)
    print("启动服务器: http://localhost:5000")
    print("=" * 50)
    
    # 启动时自动抓取数据（如果数据文件不存在）
    if not os.path.exists(crawler.data_file):
        print("首次运行，自动抓取数据...")
        crawler.crawl_all()
    
    app.run(host='0.0.0.0', port=5000, debug=True)
