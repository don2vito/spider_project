#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
炼丹炉行业报告爬虫 - 三层架构实现
目标网站: https://www.huo1818.com/report/1
"""

import json
import re
import time
import os
from datetime import datetime
from typing import List, Dict, Optional
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup


class Huo1818Crawler:
    """
    炼丹炉报告爬虫 - 三层架构
    第一层: API接口探测
    第二层: HTML解析 (主方案)
    第三层: Browser Use兜底 (备用)
    """
    
    def __init__(self, data_dir: str = "data"):
        self.base_url = "https://www.huo1818.com"
        self.report_url = f"{self.base_url}/report"
        self.data_dir = data_dir
        self.data_file = os.path.join(data_dir, "reports.json")
        
        # 创建数据目录
        os.makedirs(data_dir, exist_ok=True)
        
        # 初始化session
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        })
        
        # 加载已有数据
        self.existing_reports = self._load_existing_data()
    
    def _load_existing_data(self) -> Dict[str, dict]:
        """加载已有数据，用于去重"""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    reports = data.get('reports', [])
                    return {r['reportId']: r for r in reports}
            except Exception as e:
                print(f"加载已有数据失败: {e}")
        return {}
    
    def _save_data(self, reports: List[dict]):
        """保存数据到JSON文件"""
        data = {
            "reports": reports,
            "lastUpdate": datetime.now().isoformat(),
            "totalCount": len(reports)
        }
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"数据已保存到 {self.data_file}，共 {len(reports)} 条")
    
    # ==================== 第一层: API接口探测 ====================
    
    def try_api_endpoint(self) -> Optional[List[dict]]:
        """
        尝试直接调用后端API
        通过分析网络请求，寻找JSON端点
        """
        print("[第一层] 尝试API接口探测...")
        
        # 尝试常见的API端点
        api_endpoints = [
            "/api/reports",
            "/api/v1/reports",
            "/api/report/list",
        ]
        
        for endpoint in api_endpoints:
            url = urljoin(self.base_url, endpoint)
            try:
                response = self.session.get(url, timeout=10)
                if response.status_code == 200:
                    try:
                        data = response.json()
                        if isinstance(data, list) or (isinstance(data, dict) and 'data' in data):
                            print(f"[第一层] 找到API端点: {url}")
                            return self._parse_api_response(data)
                    except:
                        pass
            except Exception as e:
                print(f"[第一层] API端点 {endpoint} 失败: {e}")
                continue
        
        print("[第一层] 未找到可用的API端点，切换到第二层")
        return None
    
    def _parse_api_response(self, data) -> List[dict]:
        """解析API响应数据"""
        if isinstance(data, list):
            return data
        elif isinstance(data, dict):
            # 尝试常见的数据字段
            for key in ['data', 'reports', 'list', 'items', 'result']:
                if key in data and isinstance(data[key], list):
                    return data[key]
        return []
    
    # ==================== 第二层: HTML解析 (主方案) ====================
    
    def parse_html_page(self, page: int = 1) -> List[dict]:
        """
        解析HTML页面，提取报告数据
        这是主方案，通过正则表达式从HTML中提取
        """
        url = f"{self.report_url}/{page}"
        print(f"[第二层] 解析页面: {url}")
        
        try:
            response = self.session.get(url, timeout=15)
            response.raise_for_status()
            
            html = response.text
            
            # 使用正则表达式提取报告数据
            reports = self._extract_reports_from_html(html)
            
            if reports:
                print(f"[第二层] 页面 {page} 成功提取 {len(reports)} 条数据")
                return reports
            else:
                print(f"[第二层] 页面 {page} 未提取到数据")
                return []
                
        except requests.RequestException as e:
            print(f"[第二层] 请求失败: {e}")
            return []
        except Exception as e:
            print(f"[第二层] 解析异常: {e}")
            return []
    
    def _extract_reports_from_html(self, html: str) -> List[dict]:
        """
        从HTML中提取报告数据
        通过正则表达式匹配reportId模式的数据
        HTML中使用的是转义的引号 \\"
        """
        reports = []
        try:
            # 查找所有reportId (HTML中使用的是转义的引号 \\")
            report_ids = re.findall(r'reportId\\":\\"(HYBG\d+)\\"', html)
            report_ids = list(set(report_ids))  # 去重
            
            for report_id in report_ids:
                # 为每个reportId提取完整信息
                report = self._extract_single_report(html, report_id)
                if report:
                    reports.append(report)
            
            return reports
        except Exception as e:
            print(f"[HTML解析] 失败: {e}")
            return []
    
    def _extract_single_report(self, html: str, report_id: str) -> Optional[dict]:
        """从HTML中提取单个报告的完整信息"""
        try:
            # 构建匹配模式 - 查找包含该reportId的JSON对象
            # HTML中使用的是转义的引号 \\"
            pattern = rf'reportId\\":\\"{report_id}\\".*?title\\":\\"([^\\"]+)\\".*?coverUrl\\":\\"([^\\"]+)\\".*?pdfUrl\\":\\"([^\\"]+)\\".*?publishTime\\":\\"([^\\"]+)\\".*?viewCount\\":(\d+)'
            
            match = re.search(pattern, html, re.DOTALL)
            if match:
                title, cover_url, pdf_url, publish_time, view_count = match.groups()
                
                return {
                    "reportId": report_id,
                    "title": title,
                    "coverUrl": cover_url,
                    "pdfUrl": pdf_url,
                    "publishTime": publish_time,
                    "viewCount": int(view_count) if view_count else 0
                }
            
            # 如果上面的模式不匹配，尝试分别提取各个字段
            title_match = re.search(rf'reportId\\":\\"{report_id}\\".*?title\\":\\"([^\\"]+)\\"', html, re.DOTALL)
            cover_match = re.search(rf'reportId\\":\\"{report_id}\\".*?coverUrl\\":\\"([^\\"]+)\\"', html, re.DOTALL)
            pdf_match = re.search(rf'reportId\\":\\"{report_id}\\".*?pdfUrl\\":\\"([^\\"]+)\\"', html, re.DOTALL)
            time_match = re.search(rf'reportId\\":\\"{report_id}\\".*?publishTime\\":\\"([^\\"]+)\\"', html, re.DOTALL)
            view_match = re.search(rf'reportId\\":\\"{report_id}\\".*?viewCount\\":(\d+)', html, re.DOTALL)
            
            if title_match and pdf_match:
                return {
                    "reportId": report_id,
                    "title": title_match.group(1),
                    "coverUrl": cover_match.group(1) if cover_match else "",
                    "pdfUrl": pdf_match.group(1),
                    "publishTime": time_match.group(1) if time_match else "",
                    "viewCount": int(view_match.group(1)) if view_match else 0
                }
            
            return None
            
        except Exception as e:
            print(f"提取报告 {report_id} 失败: {e}")
            return None
    
    def parse_html_all_pages(self, max_pages: int = 10) -> List[dict]:
        """
        遍历所有分页，抓取全量数据
        """
        print(f"[第二层] 开始遍历所有页面 (最多{max_pages}页)...")
        all_reports = []
        
        for page in range(1, max_pages + 1):
            reports = self.parse_html_page(page)
            
            if not reports:
                print(f"[第二层] 页面 {page} 无数据，停止遍历")
                break
            
            all_reports.extend(reports)
            print(f"[第二层] 已抓取 {len(all_reports)} 条数据")
            
            # 请求间隔，避免被封
            time.sleep(0.5)
        
        return all_reports
    
    # ==================== 第三层: Browser Use兜底 ====================
    
    def browser_fallback(self, page: int = 1) -> List[dict]:
        """
        使用Playwright控制浏览器获取数据
        作为备用方案，当HTML解析失效时使用
        """
        print(f"[第三层] 使用Browser Use获取页面 {page}...")
        
        try:
            from playwright.sync_api import sync_playwright
            
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                context = browser.new_context(
                    user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                )
                page_obj = context.new_page()
                
                url = f"{self.report_url}/{page}"
                page_obj.goto(url, wait_until="networkidle", timeout=30000)
                
                # 等待页面加载完成
                page_obj.wait_for_timeout(2000)
                
                # 获取页面HTML
                html = page_obj.content()
                
                browser.close()
                
                # 从HTML中提取数据
                reports = self._extract_reports_from_html(html)
                
                if reports:
                    print(f"[第三层] 成功提取 {len(reports)} 条数据")
                    return reports
                else:
                    print("[第三层] 未获取到数据")
                    return []
                    
        except ImportError:
            print("[第三层] Playwright未安装，跳过")
            return []
        except Exception as e:
            print(f"[第三层] Browser Use失败: {e}")
            return []
    
    # ==================== 数据处理和去重 ====================
    
    def _normalize_report(self, report: dict) -> dict:
        """标准化报告数据"""
        return {
            "reportId": report.get("reportId", ""),
            "title": report.get("title", "").strip(),
            "coverUrl": report.get("coverUrl", ""),
            "pdfUrl": report.get("pdfUrl", ""),
            "publishTime": report.get("publishTime", ""),
            "viewCount": report.get("viewCount", 0),
            "detailUrl": f"{self.report_url}/{report.get('reportId', '')}",
        }
    
    def _deduplicate_reports(self, reports: List[dict]) -> List[dict]:
        """根据reportId去重"""
        seen = set()
        unique_reports = []
        
        for report in reports:
            report_id = report.get("reportId")
            if report_id and report_id not in seen:
                seen.add(report_id)
                unique_reports.append(report)
        
        return unique_reports
    
    def _merge_with_existing(self, new_reports: List[dict]) -> List[dict]:
        """与新数据合并，保留已有数据"""
        merged = self.existing_reports.copy()
        
        for report in new_reports:
            report_id = report.get("reportId")
            if report_id:
                merged[report_id] = self._normalize_report(report)
        
        return list(merged.values())
    
    # ==================== 主入口 ====================
    
    def crawl_all(self, use_browser_fallback: bool = False) -> dict:
        """
        主入口：抓取全量数据
        
        Args:
            use_browser_fallback: 是否使用浏览器兜底方案
        
        Returns:
            包含抓取结果的字典
        """
        print("=" * 50)
        print("开始抓取炼丹炉行业报告数据")
        print("=" * 50)
        
        start_time = time.time()
        reports = []
        method_used = ""
        
        # 第一层: 尝试API接口
        api_data = self.try_api_endpoint()
        if api_data:
            reports = api_data
            method_used = "API接口"
        else:
            # 第二层: HTML解析 (主方案)
            html_data = self.parse_html_all_pages(max_pages=10)
            if html_data:
                reports = html_data
                method_used = "HTML解析"
            elif use_browser_fallback:
                # 第三层: Browser Use兜底
                browser_data = self.browser_fallback()
                if browser_data:
                    reports = browser_data
                    method_used = "Browser Use"
        
        # 数据处理和保存
        if reports:
            # 标准化数据
            normalized_reports = [self._normalize_report(r) for r in reports]
            
            # 去重
            unique_reports = self._deduplicate_reports(normalized_reports)
            
            # 与已有数据合并
            final_reports = self._merge_with_existing(unique_reports)
            
            # 按发布时间排序
            final_reports.sort(
                key=lambda x: x.get("publishTime", ""), 
                reverse=True
            )
            
            # 保存数据
            self._save_data(final_reports)
            
            elapsed_time = time.time() - start_time
            
            result = {
                "success": True,
                "method": method_used,
                "total": len(final_reports),
                "new": len(unique_reports),
                "elapsed_time": round(elapsed_time, 2),
                "data_file": self.data_file
            }
            
            print("=" * 50)
            print(f"抓取完成!")
            print(f"方法: {method_used}")
            print(f"总数据: {len(final_reports)} 条")
            print(f"新数据: {len(unique_reports)} 条")
            print(f"耗时: {elapsed_time:.2f} 秒")
            print("=" * 50)
            
            return result
        else:
            print("抓取失败，未获取到数据")
            return {
                "success": False,
                "method": "none",
                "total": 0,
                "new": 0,
                "error": "未获取到数据"
            }
    
    def get_reports(self) -> List[dict]:
        """获取当前存储的所有报告"""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get('reports', [])
            except Exception as e:
                print(f"读取数据失败: {e}")
        return []
    
    def get_report_by_id(self, report_id: str) -> Optional[dict]:
        """根据ID获取单个报告"""
        reports = self.get_reports()
        for report in reports:
            if report.get('reportId') == report_id:
                return report
        return None


# 测试代码
if __name__ == "__main__":
    crawler = Huo1818Crawler()
    result = crawler.crawl_all()
    print(json.dumps(result, ensure_ascii=False, indent=2))
