/**
 * 炼丹炉行业报告爬虫 - 前端应用
 */

class ReportApp {
    constructor() {
        this.reports = [];
        this.filteredReports = [];
        this.selectedIds = new Set();
        this.currentPage = 1;
        this.pageSize = 12;
        this.viewMode = 'card';
        this.sortField = 'publishTime';
        this.searchKeyword = '';
        
        this.init();
    }
    
    async init() {
        this.bindEvents();
        await this.loadData();
    }
    
    // ==================== 事件绑定 ====================
    
    bindEvents() {
        // 刷新按钮
        document.getElementById('refreshBtn').addEventListener('click', () => this.refreshData());
        
        // 下载全部按钮
        document.getElementById('downloadAllBtn').addEventListener('click', () => this.downloadAll());
        
        // 搜索框
        const searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('input', this.debounce((e) => {
            this.searchKeyword = e.target.value.trim();
            this.currentPage = 1;
            this.filterAndRender();
        }, 300));
        
        // 排序选择
        document.getElementById('sortSelect').addEventListener('change', (e) => {
            this.sortField = e.target.value;
            this.filterAndRender();
        });
        
        // 视图切换
        document.querySelectorAll('.toggle-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.toggle-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.viewMode = btn.dataset.view;
                this.render();
            });
        });
        
        // 分页大小
        document.getElementById('pageSizeSelect').addEventListener('change', (e) => {
            this.pageSize = parseInt(e.target.value);
            this.currentPage = 1;
            this.render();
        });
        
        // 分页按钮
        document.getElementById('prevBtn').addEventListener('click', () => {
            if (this.currentPage > 1) {
                this.currentPage--;
                this.render();
                this.scrollToTop();
            }
        });
        
        document.getElementById('nextBtn').addEventListener('click', () => {
            const totalPages = Math.ceil(this.filteredReports.length / this.pageSize);
            if (this.currentPage < totalPages) {
                this.currentPage++;
                this.render();
                this.scrollToTop();
            }
        });
        
        // 全选
        document.getElementById('selectAll').addEventListener('change', (e) => {
            if (e.target.checked) {
                this.filteredReports.forEach(r => this.selectedIds.add(r.reportId));
            } else {
                this.selectedIds.clear();
            }
            this.updateBatchActions();
            this.render();
        });
    }
    
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // ==================== 数据加载 ====================
    
    async loadData() {
        this.showLoading();
        
        try {
            const response = await fetch('/api/reports');
            const result = await response.json();
            
            if (result.success) {
                this.reports = result.data || [];
                this.filteredReports = [...this.reports];
                this.updateStats();
                this.render();
                
                if (this.reports.length === 0) {
                    this.showEmpty();
                }
            } else {
                this.showError(result.error || '加载失败');
            }
        } catch (error) {
            console.error('加载数据失败:', error);
            this.showError('网络连接失败');
        }
    }
    
    async refreshData() {
        this.showRefreshModal();
        
        try {
            this.updateRefreshProgress(10, '正在连接服务器...');
            
            const response = await fetch('/api/reports/refresh', {
                method: 'POST'
            });
            
            this.updateRefreshProgress(60, '正在处理数据...');
            
            const result = await response.json();
            
            if (result.success) {
                this.updateRefreshProgress(100, '完成！');
                setTimeout(() => {
                    this.hideRefreshModal();
                    this.showToast(`✅ 成功更新 ${result.new} 条数据`, 'success');
                    this.loadData();
                }, 500);
            } else {
                this.hideRefreshModal();
                this.showToast(`❌ 更新失败: ${result.error}`, 'error');
            }
        } catch (error) {
            this.hideRefreshModal();
            this.showToast('❌ 网络连接失败', 'error');
        }
    }
    
    // ==================== 数据过滤和排序 ====================
    
    filterAndRender() {
        // 过滤
        if (this.searchKeyword) {
            const keyword = this.searchKeyword.toLowerCase();
            this.filteredReports = this.reports.filter(report => 
                report.title.toLowerCase().includes(keyword) ||
                report.reportId.toLowerCase().includes(keyword)
            );
        } else {
            this.filteredReports = [...this.reports];
        }
        
        // 排序
        this.sortReports();
        
        // 重置分页
        this.currentPage = 1;
        
        // 渲染
        this.render();
        this.updateStats();
    }
    
    sortReports() {
        this.filteredReports.sort((a, b) => {
            switch (this.sortField) {
                case 'publishTime':
                    return new Date(b.publishTime || 0) - new Date(a.publishTime || 0);
                case 'viewCount':
                    return (b.viewCount || 0) - (a.viewCount || 0);
                case 'title':
                    return (a.title || '').localeCompare(b.title || '');
                default:
                    return 0;
            }
        });
    }
    
    // ==================== 渲染 ====================
    
    render() {
        const container = document.getElementById('reportsContainer');
        const cardView = document.getElementById('cardView');
        const listView = document.getElementById('listView');
        
        // 隐藏加载状态，显示内容
        document.getElementById('loadingState').style.display = 'none';
        document.getElementById('emptyState').style.display = 'none';
        document.getElementById('errorState').style.display = 'none';
        container.style.display = 'block';
        
        // 计算分页
        const totalPages = Math.ceil(this.filteredReports.length / this.pageSize);
        const start = (this.currentPage - 1) * this.pageSize;
        const end = start + this.pageSize;
        const pageData = this.filteredReports.slice(start, end);
        
        // 渲染视图
        if (this.viewMode === 'card') {
            cardView.innerHTML = pageData.map((report, index) => this.renderCard(report, index)).join('');
            cardView.style.display = 'grid';
            listView.style.display = 'none';
        } else {
            listView.innerHTML = pageData.map(report => this.renderListItem(report)).join('');
            cardView.style.display = 'none';
            listView.style.display = 'flex';
        }
        
        // 渲染分页
        this.renderPagination(totalPages);
        
        // 绑定卡片事件
        this.bindCardEvents();
    }
    
    renderCard(report, index) {
        const isSelected = this.selectedIds.has(report.reportId);
        const date = report.publishTime ? report.publishTime.split(' ')[0] : '-';
        
        return `
            <div class="report-card" data-id="${report.reportId}" style="animation-delay: ${index * 0.05}s">
                <div class="card-image">
                    <img src="${report.coverUrl || ''}" alt="${report.title}" loading="lazy" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22280%22 height=%22180%22><rect fill=%22%23f3f4f6%22 width=%22280%22 height=%22180%22/><text fill=%22%239ca3af%22 x=%2250%%22 y=%2250%%22 text-anchor=%22middle%22>暂无封面</text></svg>'">
                    <div class="card-overlay">
                        <button class="btn btn-primary btn-sm" onclick="app.previewReport('${report.reportId}')">👁 预览</button>
                    </div>
                </div>
                <div class="card-content">
                    <h3 class="card-title">${report.title}</h3>
                    <div class="card-meta">
                        <span>📅 ${date}</span>
                        <span>👁 ${(report.viewCount || 0).toLocaleString()} 次浏览</span>
                    </div>
                </div>
                <div class="card-actions">
                    <button class="btn btn-primary btn-block" onclick="app.downloadSingle('${report.reportId}')">
                        <span class="icon">⬇️</span>
                        下载 PDF
                    </button>
                </div>
            </div>
        `;
    }
    
    renderListItem(report) {
        const isSelected = this.selectedIds.has(report.reportId);
        const date = report.publishTime ? report.publishTime.split(' ')[0] : '-';
        
        return `
            <div class="list-item" data-id="${report.reportId}">
                <div class="list-checkbox">
                    <input type="checkbox" ${isSelected ? 'checked' : ''} onchange="app.toggleSelection('${report.reportId}')">
                </div>
                <div class="list-cover">
                    <img src="${report.coverUrl || ''}" alt="${report.title}" loading="lazy" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2280%22 height=%2260%22><rect fill=%22%23f3f4f6%22 width=%2280%22 height=%2260%22/><text fill=%22%239ca3af%22 x=%2250%%22 y=%2250%%22 text-anchor=%22middle%22 font-size=%2210%22>无图</text></svg>'">
                </div>
                <div class="list-info">
                    <h4 class="list-title">${report.title}</h4>
                    <div class="list-meta">
                        <span>📅 ${date}</span>
                        <span>👁 ${(report.viewCount || 0).toLocaleString()} 次浏览</span>
                        <span>🆔 ${report.reportId}</span>
                    </div>
                </div>
                <div class="list-actions">
                    <a href="${report.pdfUrl}" target="_blank" class="btn-link">查看原文</a>
                    <button class="btn btn-sm btn-primary" onclick="app.downloadSingle('${report.reportId}')">下载</button>
                </div>
            </div>
        `;
    }
    
    renderPagination(totalPages) {
        const pagination = document.getElementById('pagination');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const pageNumbers = document.getElementById('pageNumbers');
        
        if (totalPages <= 1) {
            pagination.style.display = 'none';
            return;
        }
        
        pagination.style.display = 'flex';
        prevBtn.disabled = this.currentPage === 1;
        nextBtn.disabled = this.currentPage === totalPages;
        
        // 生成页码
        let html = '';
        const maxVisible = 5;
        
        if (totalPages <= maxVisible + 2) {
            for (let i = 1; i <= totalPages; i++) {
                html += this.renderPageButton(i);
            }
        } else {
            // 第一页
            html += this.renderPageButton(1);
            
            // 省略号
            if (this.currentPage > 3) {
                html += '<span class="page-ellipsis">...</span>';
            }
            
            // 中间页码
            const start = Math.max(2, this.currentPage - 1);
            const end = Math.min(totalPages - 1, this.currentPage + 1);
            
            for (let i = start; i <= end; i++) {
                html += this.renderPageButton(i);
            }
            
            // 省略号
            if (this.currentPage < totalPages - 2) {
                html += '<span class="page-ellipsis">...</span>';
            }
            
            // 最后一页
            html += this.renderPageButton(totalPages);
        }
        
        pageNumbers.innerHTML = html;
        
        // 绑定页码点击事件
        pageNumbers.querySelectorAll('.page-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.currentPage = parseInt(btn.dataset.page);
                this.render();
                this.scrollToTop();
            });
        });
    }
    
    renderPageButton(page) {
        const isActive = page === this.currentPage;
        return `<button class="page-btn ${isActive ? 'active' : ''}" data-page="${page}">${page}</button>`;
    }
    
    bindCardEvents() {
        // 卡片长按选择（列表视图已在render中绑定）
        if (this.viewMode === 'card') {
            document.querySelectorAll('.report-card').forEach(card => {
                const id = card.dataset.id;
                
                card.addEventListener('click', (e) => {
                    if (e.target.closest('button')) return;
                    // 点击卡片也可以选中
                    if (this.selectedIds.size > 0) {
                        this.toggleSelection(id);
                    }
                });
            });
        }
    }
    
    // ==================== 选择功能 ====================
    
    toggleSelection(reportId) {
        if (this.selectedIds.has(reportId)) {
            this.selectedIds.delete(reportId);
        } else {
            this.selectedIds.add(reportId);
        }
        this.updateBatchActions();
        this.render();
    }
    
    clearSelection() {
        this.selectedIds.clear();
        this.updateBatchActions();
        this.render();
    }
    
    updateBatchActions() {
        const batchActions = document.getElementById('batchActions');
        const selectedCount = document.getElementById('selectedCount');
        const selectAll = document.getElementById('selectAll');
        
        selectedCount.textContent = this.selectedIds.size;
        
        if (this.selectedIds.size > 0) {
            batchActions.style.display = 'flex';
            // 更新全选框状态
            const allIds = this.filteredReports.map(r => r.reportId);
            const allSelected = allIds.length > 0 && allIds.every(id => this.selectedIds.has(id));
            selectAll.checked = allSelected;
        } else {
            batchActions.style.display = 'none';
            selectAll.checked = false;
        }
    }
    
    // ==================== 下载功能 ====================
    
    async downloadSingle(reportId) {
        this.showDownloadModal();
        this.updateDownloadProgress(50, '正在下载...');
        
        try {
            window.location.href = `/api/download/${reportId}`;
            
            setTimeout(() => {
                this.hideDownloadModal();
                this.showToast('✅ 下载已开始', 'success');
            }, 1000);
        } catch (error) {
            this.hideDownloadModal();
            this.showToast('❌ 下载失败', 'error');
        }
    }
    
    async downloadSelected() {
        if (this.selectedIds.size === 0) {
            this.showToast('请先选择要下载的报告', 'warning');
            return;
        }
        
        this.showDownloadModal();
        this.updateDownloadProgress(30, '正在打包...');
        
        try {
            const response = await fetch('/api/download/batch', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    ids: Array.from(this.selectedIds)
                })
            });
            
            this.updateDownloadProgress(80, '准备下载...');
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `reports_batch_${new Date().getTime()}.zip`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                
                this.updateDownloadProgress(100, '完成！');
                setTimeout(() => {
                    this.hideDownloadModal();
                    this.showToast(`✅ 成功下载 ${this.selectedIds.size} 个文件`, 'success');
                    this.clearSelection();
                }, 500);
            } else {
                throw new Error('下载失败');
            }
        } catch (error) {
            this.hideDownloadModal();
            this.showToast('❌ 下载失败', 'error');
        }
    }
    
    async downloadAll() {
        if (this.reports.length === 0) {
            this.showToast('暂无数据可下载', 'warning');
            return;
        }
        
        if (!confirm(`确定要下载全部 ${this.reports.length} 个报告吗？`)) {
            return;
        }
        
        this.showDownloadModal();
        this.updateDownloadProgress(10, '正在准备下载...');
        
        try {
            // 模拟进度
            let progress = 10;
            const interval = setInterval(() => {
                progress += 5;
                if (progress < 90) {
                    this.updateDownloadProgress(progress, '正在打包文件...');
                }
            }, 500);
            
            const response = await fetch('/api/download/all');
            clearInterval(interval);
            
            this.updateDownloadProgress(95, '准备下载...');
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `reports_all_${new Date().getTime()}.zip`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                
                this.updateDownloadProgress(100, '完成！');
                setTimeout(() => {
                    this.hideDownloadModal();
                    this.showToast('✅ 全量下载已开始', 'success');
                }, 500);
            } else {
                throw new Error('下载失败');
            }
        } catch (error) {
            this.hideDownloadModal();
            this.showToast('❌ 下载失败', 'error');
        }
    }
    
    previewReport(reportId) {
        const report = this.reports.find(r => r.reportId === reportId);
        if (report && report.pdfUrl) {
            window.open(report.pdfUrl, '_blank');
        }
    }
    
    // ==================== UI 状态 ====================
    
    showLoading() {
        document.getElementById('loadingState').style.display = 'flex';
        document.getElementById('emptyState').style.display = 'none';
        document.getElementById('errorState').style.display = 'none';
        document.getElementById('reportsContainer').style.display = 'none';
        document.getElementById('pagination').style.display = 'none';
    }
    
    showEmpty() {
        document.getElementById('loadingState').style.display = 'none';
        document.getElementById('emptyState').style.display = 'flex';
        document.getElementById('errorState').style.display = 'none';
        document.getElementById('reportsContainer').style.display = 'none';
        document.getElementById('pagination').style.display = 'none';
    }
    
    showError(message) {
        document.getElementById('loadingState').style.display = 'none';
        document.getElementById('emptyState').style.display = 'none';
        document.getElementById('errorState').style.display = 'flex';
        document.getElementById('errorMessage').textContent = message;
        document.getElementById('reportsContainer').style.display = 'none';
        document.getElementById('pagination').style.display = 'none';
    }
    
    showRefreshModal() {
        document.getElementById('refreshModal').style.display = 'flex';
        this.updateRefreshProgress(0, '准备中...');
    }
    
    hideRefreshModal() {
        document.getElementById('refreshModal').style.display = 'none';
    }
    
    updateRefreshProgress(percent, text) {
        document.getElementById('refreshProgress').style.width = `${percent}%`;
        document.getElementById('refreshText').textContent = text;
    }
    
    showDownloadModal() {
        document.getElementById('downloadModal').style.display = 'flex';
        this.updateDownloadProgress(0, '准备中...');
    }
    
    hideDownloadModal() {
        document.getElementById('downloadModal').style.display = 'none';
    }
    
    updateDownloadProgress(percent, text) {
        document.getElementById('downloadProgress').style.width = `${percent}%`;
        document.getElementById('downloadText').textContent = text;
    }
    
    showToast(message, type = 'success') {
        const toast = document.getElementById('toast');
        const toastIcon = document.getElementById('toastIcon');
        const toastMessage = document.getElementById('toastMessage');
        
        toastIcon.textContent = type === 'success' ? '✅' : type === 'error' ? '❌' : '⚠️';
        toastMessage.textContent = message;
        
        toast.style.display = 'flex';
        
        setTimeout(() => {
            toast.style.display = 'none';
        }, 3000);
    }
    
    updateStats() {
        const totalCount = this.filteredReports.length;
        const totalViews = this.filteredReports.reduce((sum, r) => sum + (r.viewCount || 0), 0);
        
        document.getElementById('totalCount').textContent = totalCount.toLocaleString();
        document.getElementById('totalViews').textContent = totalViews.toLocaleString();
    }
    
    scrollToTop() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

// 初始化应用
const app = new ReportApp();
