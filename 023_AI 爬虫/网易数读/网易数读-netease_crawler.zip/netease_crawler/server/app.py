# -*- coding: utf-8 -*-
"""
网易数读栏目爬虫系统 - Flask主应用
"""

import os
import json
import logging
from datetime import datetime
from flask import Flask, jsonify, request, send_from_directory, send_file
from flask_cors import CORS

from config import SERVER_HOST, SERVER_PORT, DOWNLOADS_DIR
from crawler.html_parser import crawler as html_crawler
from crawler.api_layer import api_crawler
from crawler.browser_layer import browser_crawler
from crawler.pdf_generator import PDFGenerator
from utils.helpers import ensure_dir, extract_article_id

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 获取当前文件所在目录
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, '..', 'frontend')

# 创建Flask应用
app = Flask(__name__)
CORS(app)

# 确保目录存在
ensure_dir(os.path.join(BASE_DIR, DOWNLOADS_DIR))

# 全局数据缓存
articles_cache = {
    'data': [],
    'last_update': None,
    'total': 0
}

# PDF生成器
pdf_generator = PDFGenerator(output_dir=os.path.join(BASE_DIR, DOWNLOADS_DIR))


# ==================== 页面路由 ====================

@app.route('/')
def index():
    """主页"""
    return send_from_directory(FRONTEND_DIR, 'index.html')


@app.route('/downloads/<filename>')
def download_file(filename):
    """下载文件"""
    try:
        return send_from_directory(os.path.join(BASE_DIR, DOWNLOADS_DIR), filename, as_attachment=True)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 404


# ==================== API路由 ====================

@app.route('/api/articles', methods=['GET'])
def get_articles():
    """
    获取文章列表
    
    Query params:
        - refresh: 是否刷新数据 (true/false)
    """
    try:
        refresh = request.args.get('refresh', 'false').lower() == 'true'
        
        # 如果需要刷新或缓存为空，则重新抓取
        if refresh or not articles_cache['data']:
            logger.info("开始抓取文章数据...")
            articles = fetch_articles_with_fallback()
            
            articles_cache['data'] = articles
            articles_cache['total'] = len(articles)
            articles_cache['last_update'] = datetime.now().isoformat()
        
        return jsonify({
            'success': True,
            'data': articles_cache['data'],
            'total': articles_cache['total'],
            'timestamp': articles_cache['last_update']
        })
        
    except Exception as e:
        logger.error(f"获取文章列表失败: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'data': [],
            'total': 0
        }), 500


@app.route('/api/articles/<article_id>', methods=['GET'])
def get_article_detail(article_id):
    """获取文章详情"""
    try:
        # 从缓存中查找文章URL
        article_url = None
        for article in articles_cache['data']:
            if article.get('id') == article_id:
                article_url = article.get('url')
                break
        
        if not article_url:
            # 尝试构建URL
            article_url = f"https://www.163.com/data/article/{article_id}.html"
        
        logger.info(f"获取文章详情: {article_url}")
        detail = html_crawler.fetch_article_detail(article_url)
        
        return jsonify({
            'success': True,
            'data': {
                'id': article_id,
                'url': article_url,
                **detail
            }
        })
        
    except Exception as e:
        logger.error(f"获取文章详情失败: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/articles/<article_id>/pdf', methods=['POST'])
def generate_article_pdf(article_id):
    """生成单篇文章PDF"""
    try:
        # 获取文章详情
        article_url = None
        article_title = article_id
        
        for article in articles_cache['data']:
            if article.get('id') == article_id:
                article_url = article.get('url')
                article_title = article.get('title', article_id)
                break
        
        if not article_url:
            article_url = f"https://www.163.com/data/article/{article_id}.html"
        
        # 获取详情
        detail = html_crawler.fetch_article_detail(article_url)
        title = detail.get('title') or article_title
        images = detail.get('content_images', [])
        
        if not images:
            return jsonify({
                'success': False,
                'error': '文章没有内容图片'
            })
        
        # 生成PDF
        result = pdf_generator.generate_pdf(title, images)
        
        if result['success']:
            return jsonify({
                'success': True,
                'data': {
                    'pdf_url': f"/downloads/{result['filename']}",
                    'filename': result['filename'],
                    'page_count': result['page_count']
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': result.get('error', 'PDF生成失败')
            })
            
    except Exception as e:
        logger.error(f"生成PDF失败: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/articles/batch/pdf', methods=['POST'])
def generate_batch_pdf():
    """批量生成PDF"""
    try:
        data = request.get_json()
        article_ids = data.get('article_ids', [])
        
        if not article_ids:
            return jsonify({
                'success': False,
                'error': '未指定文章ID'
            })
        
        # 收集文章信息
        articles_to_process = []
        
        for article_id in article_ids:
            # 从缓存查找
            article_info = None
            for article in articles_cache['data']:
                if article.get('id') == article_id:
                    article_info = article
                    break
            
            if article_info:
                # 获取详情
                detail = html_crawler.fetch_article_detail(article_info.get('url', ''))
                articles_to_process.append({
                    'title': detail.get('title') or article_info.get('title', article_id),
                    'content_images': detail.get('content_images', [])
                })
        
        if not articles_to_process:
            return jsonify({
                'success': False,
                'error': '未找到有效文章'
            })
        
        # 批量生成PDF
        result = pdf_generator.generate_batch_pdf(articles_to_process)
        
        if result['success']:
            return jsonify({
                'success': True,
                'data': {
                    'zip_url': f"/downloads/{result['zip_filename']}",
                    'zip_filename': result['zip_filename'],
                    'total': result['total'],
                    'success_count': result['success_count'],
                    'failed_count': result['failed_count']
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': result.get('error', '批量生成失败')
            })
            
    except Exception as e:
        logger.error(f"批量生成PDF失败: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/refresh', methods=['POST'])
def refresh_data():
    """刷新数据"""
    try:
        logger.info("手动刷新数据...")
        articles = fetch_articles_with_fallback()
        
        old_count = articles_cache['total']
        new_count = len(articles)
        
        articles_cache['data'] = articles
        articles_cache['total'] = new_count
        articles_cache['last_update'] = datetime.now().isoformat()
        
        return jsonify({
            'success': True,
            'data': {
                'new_count': max(0, new_count - old_count),
                'total_count': new_count,
                'timestamp': articles_cache['last_update']
            }
        })
        
    except Exception as e:
        logger.error(f"刷新数据失败: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/stats', methods=['GET'])
def get_stats():
    """获取统计信息"""
    try:
        # 统计已下载的PDF数量
        downloaded_count = 0
        try:
            downloads_path = os.path.join(BASE_DIR, DOWNLOADS_DIR)
            for f in os.listdir(downloads_path):
                if f.endswith('.pdf'):
                    downloaded_count += 1
        except:
            pass
        
        # 统计今日新增
        today = datetime.now().date()
        today_count = 0
        for article in articles_cache['data']:
            try:
                pub_time = article.get('publish_time', '')
                if pub_time:
                    pub_date = datetime.strptime(pub_time[:10], '%Y-%m-%d').date()
                    if pub_date == today:
                        today_count += 1
            except:
                pass
        
        return jsonify({
            'success': True,
            'data': {
                'total_count': articles_cache['total'],
                'today_count': today_count,
                'downloaded_count': downloaded_count,
                'last_update': articles_cache['last_update']
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==================== 辅助函数 ====================

def fetch_articles_with_fallback():
    """使用三层策略获取文章"""
    
    # 第一层：尝试API
    logger.info("第一层：尝试API接口...")
    articles = api_crawler.fetch_articles()
    if articles:
        logger.info(f"API接口成功，获取 {len(articles)} 篇文章")
        return articles
    
    # 第二层：HTML解析
    logger.info("第二层：使用HTML解析...")
    articles = html_crawler.fetch_articles()
    if articles:
        logger.info(f"HTML解析成功，获取 {len(articles)} 篇文章")
        return articles
    
    # 第三层：Browser Use
    logger.info("第三层：使用Browser Use...")
    articles = browser_crawler.fetch_articles()
    if articles:
        logger.info(f"Browser Use成功，获取 {len(articles)} 篇文章")
        return articles
    
    logger.error("所有层级均失败")
    return []


# ==================== 启动服务器 ====================

if __name__ == '__main__':
    logger.info(f"启动服务器: http://{SERVER_HOST}:{SERVER_PORT}")
    app.run(
        host=SERVER_HOST,
        port=SERVER_PORT,
        debug=False,
        threaded=True
    )
