# -*- coding: utf-8 -*-
"""
网易数读栏目爬虫系统 - 配置文件
"""

# 目标网站配置
TARGET_URL = "https://data.163.com/special/datablog/"
ARTICLE_URL_TEMPLATE = "https://www.163.com/data/article/{article_id}.html"

# 服务器配置
# 使用 0.0.0.0 允许外部访问，127.0.0.1 只允许本地访问
SERVER_HOST = "0.0.0.0"
SERVER_PORT = 5000

# 爬虫配置
REQUEST_TIMEOUT = 30
REQUEST_DELAY = 1.0  # 请求间隔（秒）
MAX_RETRIES = 3
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
]

# PDF配置
PDF_PAGE_WIDTH = 612  # A4宽度（点）
PDF_PAGE_HEIGHT = 792  # A4高度（点）
PDF_MARGIN = 20

# 数据目录
DATA_DIR = "data"
DOWNLOADS_DIR = "data/downloads"
CACHE_DIR = "data/cache"

# 日志配置
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
