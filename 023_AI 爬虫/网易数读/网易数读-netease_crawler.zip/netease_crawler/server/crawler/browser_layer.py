# -*- coding: utf-8 -*-
"""
网易数读栏目爬虫系统 - Browser Use爬虫（第三层兜底方案）
"""

import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)


class BrowserCrawler:
    """Browser Use爬虫 - 使用Playwright控制浏览器获取数据"""
    
    def __init__(self):
        self.timeout = 30
        self.headless = True
        
    def fetch_articles(self) -> List[Dict[str, Any]]:
        """
        使用浏览器获取文章列表
        
        Note:
            这是第三层兜底方案，当HTML解析失效时使用
            需要安装playwright: pip install playwright && playwright install
        """
        logger.info("尝试Browser Use获取数据...")
        
        try:
            from playwright.sync_api import sync_playwright
            return self._fetch_with_playwright()
        except ImportError:
            logger.warning("Playwright未安装，Browser Use不可用")
            return []
        except Exception as e:
            logger.error(f"Browser Use执行失败: {e}")
            return []
    
    def _fetch_with_playwright(self) -> List[Dict[str, Any]]:
        """使用Playwright获取数据"""
        from playwright.sync_api import sync_playwright
        import re
        import json
        
        articles = []
        
        try:
            from playwright.sync_api import sync_playwright
            
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=self.headless)
                page = browser.new_page()
                
                # 访问页面
                page.goto("https://data.163.com/special/datablog/", timeout=self.timeout * 1000)
                page.wait_for_load_state("networkidle")
                
                # 尝试从页面获取JavaScript变量
                js_data = page.evaluate("() => typeof ohnofuchlist !== 'undefined' ? ohnofuchlist : null")
                
                if js_data:
                    for item in js_data:
                        article = {
                            'id': self._extract_id(item.get('url', '')),
                            'title': item.get('title', ''),
                            'url': item.get('url', ''),
                            'cover_image': item.get('img', ''),
                            'publish_time': item.get('time', ''),
                            'comment_count': item.get('comment', '0'),
                            'keywords': item.get('keyword', '').split(',') if item.get('keyword') else []
                        }
                        if article['id']:
                            articles.append(article)
                
                browser.close()
                
        except Exception as e:
            logger.error(f"Playwright执行失败: {e}")
            
        return articles
    
    def _extract_id(self, url: str) -> str:
        """从URL提取文章ID"""
        import re
        match = re.search(r'/article/([A-Z0-9]+)\.html', url)
        return match.group(1) if match else ''
    
    def is_available(self) -> bool:
        """检查Browser Use是否可用"""
        try:
            import playwright
            return True
        except ImportError:
            return False


# 创建全局实例
browser_crawler = BrowserCrawler()
