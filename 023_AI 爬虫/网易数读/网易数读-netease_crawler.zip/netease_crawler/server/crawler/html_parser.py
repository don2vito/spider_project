# -*- coding: utf-8 -*-
"""
网易数读栏目爬虫系统 - HTML解析爬虫（第二层主方案）
"""

import re
import json
import time
import random
import logging
from typing import List, Dict, Any, Optional
import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


class HTMLParserCrawler:
    """HTML解析爬虫 - 通过解析页面JavaScript变量获取数据"""
    
    def __init__(self):
        self.target_url = "https://data.163.com/special/datablog/"
        self.timeout = 30
        self.max_retries = 3
        self.session = requests.Session()
        
    def fetch_articles(self) -> List[Dict[str, Any]]:
        """获取所有文章列表"""
        logger.info(f"开始抓取文章列表: {self.target_url}")
        
        for attempt in range(self.max_retries):
            try:
                headers = self._get_headers()
                response = self.session.get(
                    self.target_url,
                    headers=headers,
                    timeout=self.timeout
                )
                
                # 直接使用原始字节，然后使用正确的编码
                raw_content = response.content
                
                # 尝试使用 GB18030（GB2312的扩展，兼容性更好）
                try:
                    html = raw_content.decode('gb18030', errors='strict')
                except:
                    try:
                        html = raw_content.decode('gb2312', errors='strict')
                    except:
                        html = raw_content.decode('utf-8', errors='replace')
                
                # 提取JavaScript变量中的数据
                articles = self._extract_articles_from_html(html)
                
                if articles:
                    logger.info(f"成功获取 {len(articles)} 篇文章")
                    return articles
                else:
                    logger.warning("未找到文章数据，尝试备用解析方法")
                    articles = self._parse_articles_from_dom(html)
                    if articles:
                        return articles
                        
            except requests.RequestException as e:
                logger.error(f"请求失败 (尝试 {attempt + 1}/{self.max_retries}): {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(2.0)
                    
        logger.error("所有尝试均失败")
        return []
    
    def _get_headers(self) -> Dict[str, str]:
        """获取请求头"""
        user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        ]
        return {
            "User-Agent": random.choice(user_agents),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        }
    
    def _extract_articles_from_html(self, html: str) -> List[Dict[str, Any]]:
        """从HTML中提取JavaScript变量ohnofuchlist"""
        
        # 查找变量开始位置
        start_pattern = r'var\s+ohnofuchlist\s*=\s*\['
        start_match = re.search(start_pattern, html)
        
        if start_match:
            logger.info("找到ohnofuchlist变量")
            
            # 从开始位置找到结束位置
            start_pos = start_match.end() - 1  # 包含 [
            end_pos = html.find('];', start_pos)
            
            if end_pos > start_pos:
                data_str = html[start_pos:end_pos + 1]  # 包含 ]
                return self._parse_article_data(data_str)
                
        return []
    
    def _parse_article_data(self, data_str: str) -> List[Dict[str, Any]]:
        """解析文章数据"""
        articles = []
        
        # 使用正则提取每个文章对象
        obj_pattern = r'\{\s*"url"\s*:\s*"([^"]+)"[^}]*"title"\s*:\s*"([^"]+)"[^}]*"img"\s*:\s*"([^"]+)"[^}]*"time"\s*:\s*"([^"]+)"[^}]*"comment"\s*:\s*\'([^\']+)\'[^}]*"keyword"\s*:\s*\'([^\']+)\'[^}]*\}'
        
        matches = re.findall(obj_pattern, data_str, re.DOTALL)
        
        for match in matches:
            url, title, img, time_str, comment, keyword = match
            
            article_id = self._extract_article_id(url)
            if article_id:
                articles.append({
                    'id': article_id,
                    'title': title,
                    'url': url,
                    'cover_image': img,
                    'publish_time': time_str,
                    'comment_count': comment,
                    'keywords': [k.strip() for k in keyword.split(',') if k.strip()]
                })
        
        logger.info(f"解析到 {len(articles)} 篇文章")
        return articles
    
    def _extract_article_id(self, url: str) -> Optional[str]:
        """从URL中提取文章ID"""
        pattern = r'/article/([A-Z0-9]+)\.html'
        match = re.search(pattern, url)
        return match.group(1) if match else None
    
    def _parse_articles_from_dom(self, html: str) -> List[Dict[str, Any]]:
        """从DOM结构中解析文章列表（备用方法）"""
        soup = BeautifulSoup(html, 'html.parser')
        articles = []
        
        for link in soup.find_all('a', href=True):
            href = link.get('href', '')
            
            if '/data/article/' in href and '.html' in href:
                article_id = self._extract_article_id(href)
                if not article_id:
                    continue
                    
                title = link.get('title', '') or link.get_text(strip=True)
                if not title or len(title) < 5:
                    continue
                    
                img = link.find('img')
                cover_image = img.get('src', '') if img else ''
                
                if not any(a['id'] == article_id for a in articles):
                    articles.append({
                        'id': article_id,
                        'title': title,
                        'url': href,
                        'cover_image': cover_image,
                        'publish_time': '',
                        'comment_count': '0',
                        'keywords': []
                    })
                    
        return articles
    
    def fetch_article_detail(self, url: str) -> Dict[str, Any]:
        """获取文章详情页内容"""
        logger.info(f"获取文章详情: {url}")
        
        for attempt in range(self.max_retries):
            try:
                time.sleep(0.5 + random.uniform(0, 0.5))
                
                headers = self._get_headers()
                response = self.session.get(
                    url,
                    headers=headers,
                    timeout=self.timeout
                )
                
                # 详情页使用 UTF-8 编码
                html = response.content.decode('utf-8', errors='replace')
                
                return self._parse_article_detail(html, url)
                
            except requests.RequestException as e:
                logger.error(f"获取详情失败 (尝试 {attempt + 1}): {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(2.0)
                    
        return {'title': '', 'content_images': [], 'content_text': ''}
    
    def _parse_article_detail(self, html: str, url: str) -> Dict[str, Any]:
        """解析文章详情页"""
        soup = BeautifulSoup(html, 'html.parser')
        
        # 获取标题
        title = ''
        title_tag = soup.find('h1')
        if title_tag:
            title = title_tag.get_text(strip=True)
        
        # 获取正文区域 - 多种选择器尝试
        content_div = (
            soup.find('div', class_='post_body') or
            soup.find('div', class_='post_text') or
            soup.find('div', class_='article-body') or
            soup.find('div', class_='post_content') or
            soup.find('article') or
            soup.find('div', id='content')
        )
        
        # 获取所有图片
        content_images = []
        if content_div:
            for img in content_div.find_all('img'):
                src = img.get('src', '') or img.get('data-src', '')
                if src:
                    if src.startswith('//'):
                        src = 'https:' + src
                    elif src.startswith('/'):
                        src = 'https://www.163.com' + src
                    content_images.append(src)
        
        # 如果内容区域没有找到图片，尝试从整个页面查找
        if not content_images:
            for img in soup.find_all('img'):
                src = img.get('src', '') or img.get('data-src', '')
                if src and ('nimg.ws.126.net' in src or 'cms-bucket' in src):
                    if src.startswith('//'):
                        src = 'https:' + src
                    content_images.append(src)
        
        # 获取正文文本
        content_text = content_div.get_text(strip=True) if content_div else ''
        
        return {
            'title': title,
            'content_images': content_images,
            'content_text': content_text[:500]
        }


# 创建全局实例
crawler = HTMLParserCrawler()
