# -*- coding: utf-8 -*-
"""
网易数读栏目爬虫系统 - PDF生成模块
"""

import os
import io
import re
import time
import random
import logging
import zipfile
import tempfile
from typing import List, Dict, Any, Optional
from datetime import datetime

import requests
from PIL import Image
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

logger = logging.getLogger(__name__)


def sanitize_filename(filename: str) -> str:
    """清理文件名，移除非法字符"""
    illegal_chars = r'[<>:"/\\|?*]'
    filename = re.sub(illegal_chars, '_', filename)
    if len(filename) > 200:
        filename = filename[:200]
    return filename.strip()


def ensure_dir(path: str):
    """确保目录存在"""
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)


def get_request_headers() -> Dict[str, str]:
    """获取请求头"""
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ]
    return {
        "User-Agent": random.choice(user_agents),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    }


def delay_request(seconds: float = 1.0):
    """请求延迟"""
    time.sleep(seconds + random.uniform(0, 0.5))


class PDFGenerator:
    """PDF生成器 - 将文章图片转换为PDF"""
    
    def __init__(self, output_dir: str = "data/downloads"):
        self.output_dir = output_dir
        self.timeout = 30
        self.max_retries = 3
        ensure_dir(output_dir)
        
    def generate_pdf(
        self,
        title: str,
        image_urls: List[str],
        output_filename: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        生成PDF文件
        
        Args:
            title: 文章标题（用作文件名）
            image_urls: 图片URL列表
            output_filename: 自定义输出文件名（可选）
            
        Returns:
            包含PDF信息的字典
        """
        if not image_urls:
            return {
                'success': False,
                'error': '没有图片可生成PDF',
                'pdf_path': None,
                'filename': None,
                'page_count': 0
            }
        
        # 生成文件名
        if not output_filename:
            filename = sanitize_filename(title) + ".pdf"
        else:
            filename = output_filename
            if not filename.endswith('.pdf'):
                filename += '.pdf'
        
        pdf_path = os.path.join(self.output_dir, filename)
        
        logger.info(f"开始生成PDF: {filename}, 图片数量: {len(image_urls)}")
        
        try:
            # 创建PDF
            c = canvas.Canvas(pdf_path, pagesize=A4)
            width, height = A4
            margin = 20
            
            page_count = 0
            for i, img_url in enumerate(image_urls):
                logger.debug(f"处理图片 {i+1}/{len(image_urls)}")
                
                try:
                    # 下载图片
                    img = self._download_image(img_url)
                    if img is None:
                        logger.warning(f"图片下载失败，跳过: {img_url}")
                        continue
                    
                    # 转换为RGB模式（PDF不支持RGBA）
                    if img.mode == 'RGBA':
                        background = Image.new('RGB', img.size, (255, 255, 255))
                        background.paste(img, mask=img.split()[3])
                        img = background
                    elif img.mode != 'RGB':
                        img = img.convert('RGB')
                    
                    # 计算缩放比例，保持宽高比
                    img_width, img_height = img.size
                    available_width = width - 2 * margin
                    available_height = height - 2 * margin
                    
                    scale = min(
                        available_width / img_width,
                        available_height / img_height
                    )
                    
                    new_width = img_width * scale
                    new_height = img_height * scale
                    
                    # 居中放置
                    x = (width - new_width) / 2
                    y = (height - new_height) / 2
                    
                    # 绘制图片
                    img_reader = ImageReader(img)
                    c.drawImage(img_reader, x, y, width=new_width, height=new_height)
                    
                    # 添加新页面
                    c.showPage()
                    page_count += 1
                    
                    # 请求延迟
                    delay_request(0.3)
                    
                except Exception as e:
                    logger.error(f"处理图片失败: {e}")
                    continue
            
            # 保存PDF
            c.save()
            
            if page_count == 0:
                return {
                    'success': False,
                    'error': '所有图片处理失败',
                    'pdf_path': None,
                    'filename': None,
                    'page_count': 0
                }
            
            logger.info(f"PDF生成成功: {filename}, 页数: {page_count}")
            
            return {
                'success': True,
                'pdf_path': pdf_path,
                'filename': filename,
                'page_count': page_count,
                'error': None
            }
            
        except Exception as e:
            logger.error(f"PDF生成失败: {e}")
            return {
                'success': False,
                'error': str(e),
                'pdf_path': None,
                'filename': None,
                'page_count': 0
            }
    
    def _download_image(self, url: str) -> Optional[Image.Image]:
        """下载图片"""
        for attempt in range(self.max_retries):
            try:
                headers = get_request_headers()
                response = requests.get(
                    url,
                    headers=headers,
                    timeout=self.timeout,
                    stream=True
                )
                response.raise_for_status()
                
                # 使用PIL打开图片
                img = Image.open(io.BytesIO(response.content))
                return img
                
            except Exception as e:
                logger.debug(f"图片下载失败 (尝试 {attempt + 1}): {e}")
                if attempt < self.max_retries - 1:
                    delay_request(1.0)
                    
        return None
    
    def generate_batch_pdf(
        self,
        articles: List[Dict[str, Any]],
        progress_callback=None
    ) -> Dict[str, Any]:
        """
        批量生成PDF并打包为ZIP
        
        Args:
            articles: 文章列表，每个包含title和content_images
            progress_callback: 进度回调函数
            
        Returns:
            包含ZIP文件信息的字典
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        zip_filename = f"batch_{timestamp}.zip"
        zip_path = os.path.join(self.output_dir, zip_filename)
        
        success_count = 0
        failed_count = 0
        pdf_files = []
        
        try:
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for i, article in enumerate(articles):
                    if progress_callback:
                        progress_callback(i, len(articles), article.get('title', ''))
                    
                    result = self.generate_pdf(
                        title=article.get('title', f'article_{i}'),
                        image_urls=article.get('content_images', [])
                    )
                    
                    if result['success']:
                        # 将PDF添加到ZIP
                        pdf_path = result['pdf_path']
                        pdf_name = result['filename']
                        zipf.write(pdf_path, pdf_name)
                        pdf_files.append(pdf_name)
                        success_count += 1
                        
                        # 删除临时PDF文件
                        try:
                            os.remove(pdf_path)
                        except:
                            pass
                    else:
                        failed_count += 1
                        
            return {
                'success': True,
                'zip_path': zip_path,
                'zip_filename': zip_filename,
                'total': len(articles),
                'success_count': success_count,
                'failed_count': failed_count,
                'pdf_files': pdf_files
            }
            
        except Exception as e:
            logger.error(f"批量生成PDF失败: {e}")
            return {
                'success': False,
                'error': str(e),
                'zip_path': None,
                'zip_filename': None,
                'total': len(articles),
                'success_count': success_count,
                'failed_count': failed_count
            }
    
    def get_pdf_url(self, filename: str) -> str:
        """获取PDF下载URL"""
        return f"/downloads/{filename}"


# 创建全局实例
pdf_generator = PDFGenerator()
