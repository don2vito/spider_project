#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试爬虫功能 - 检查编码和图片问题
"""

import re
import json
import logging
import requests
from bs4 import BeautifulSoup

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_request_headers():
    return {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    }

def extract_article_id(url):
    pattern = r'/article/([A-Z0-9]+)\.html'
    match = re.search(pattern, url)
    return match.group(1) if match else None

def fetch_articles():
    """获取文章列表"""
    url = "https://data.163.com/special/datablog/"
    
    logger.info(f"开始抓取: {url}")
    
    try:
        response = requests.get(url, headers=get_request_headers(), timeout=30)
        # 使用GB2312编码解码
        html = response.content.decode('gb2312', errors='replace')
        
        logger.info(f"页面大小: {len(html)} 字符")
        
        # 提取JavaScript变量
        start_pattern = r'var\s+ohnofuchlist\s*=\s*\['
        start_match = re.search(start_pattern, html)
        
        if start_match:
            logger.info("找到ohnofuchlist变量")
            
            start_pos = start_match.end() - 1
            end_pos = html.find('];', start_pos)
            
            if end_pos > start_pos:
                data_str = html[start_pos:end_pos + 1]
                return parse_article_data(data_str)
        
        return []
        
    except Exception as e:
        logger.error(f"抓取失败: {e}")
        import traceback
        traceback.print_exc()
    
    return []

def parse_article_data(data_str):
    """解析文章数据"""
    articles = []
    
    obj_pattern = r'\{\s*"url"\s*:\s*"([^"]+)"[^}]*"title"\s*:\s*"([^"]+)"[^}]*"img"\s*:\s*"([^"]+)"[^}]*"time"\s*:\s*"([^"]+)"[^}]*"comment"\s*:\s*\'([^\']+)\'[^}]*"keyword"\s*:\s*\'([^\']+)\'[^}]*\}'
    
    matches = re.findall(obj_pattern, data_str, re.DOTALL)
    
    for match in matches:
        url, title, img, time_str, comment, keyword = match
        
        article_id = extract_article_id(url)
        if article_id:
            articles.append({
                'id': article_id,
                'title': title,
                'url': url,
                'cover_image': img,
                'publish_time': time_str,
                'comment_count': comment,
                'keywords': [k.strip() for k in keyword.split(',') if k.strip()]
            })
    
    logger.info(f"解析到 {len(articles)} 篇文章")
    return articles

def fetch_article_detail(url):
    """获取文章详情"""
    try:
        response = requests.get(url, headers=get_request_headers(), timeout=30)
        html = response.content.decode('utf-8', errors='ignore')
        
        soup = BeautifulSoup(html, 'html.parser')
        
        # 获取标题
        title = ''
        title_tag = soup.find('h1')
        if title_tag:
            title = title_tag.get_text(strip=True)
        
        # 获取正文区域 - 多种选择器尝试
        content_div = (
            soup.find('div', class_='post_body') or
            soup.find('div', class_='post_text') or
            soup.find('div', class_='article-body') or
            soup.find('div', class_='post_content') or
            soup.find('article') or
            soup.find('div', id='content')
        )
        
        # 获取图片
        images = []
        if content_div:
            for img in content_div.find_all('img'):
                src = img.get('src', '') or img.get('data-src', '')
                if src:
                    if src.startswith('//'):
                        src = 'https:' + src
                    images.append(src)
        
        # 如果没有找到内容区域，尝试其他方式
        if not images:
            # 查找所有图片
            for img in soup.find_all('img'):
                src = img.get('src', '') or img.get('data-src', '')
                if src and ('nimg.ws.126.net' in src or 'cms-bucket' in src):
                    if src.startswith('//'):
                        src = 'https:' + src
                    images.append(src)
        
        return {'title': title, 'content_images': images}
        
    except Exception as e:
        logger.error(f"获取详情失败: {e}")
        return {'title': '', 'content_images': []}

def main():
    print("=" * 60)
    print("网易数读爬虫测试 - 检查编码和图片")
    print("=" * 60)
    
    print("\n[测试1] 获取文章列表...")
    articles = fetch_articles()
    
    if articles:
        print(f"✅ 成功获取 {len(articles)} 篇文章")
        print("\n前3篇文章（检查编码）:")
        for i, article in enumerate(articles[:3]):
            print(f"\n--- 文章 {i+1} ---")
            print(f"ID: {article.get('id')}")
            print(f"标题: {article.get('title')}")
            print(f"标题类型: {type(article.get('title'))}")
            print(f"标题字节: {article.get('title').encode('utf-8')[:50]}...")
            print(f"链接: {article.get('url')}")
    else:
        print("❌ 获取文章列表失败")
        return False
    
    if articles:
        print("\n" + "=" * 60)
        print("[测试2] 获取文章详情（检查图片）...")
        first_article = articles[0]
        print(f"正在获取: {first_article['title']}")
        
        detail = fetch_article_detail(first_article['url'])
        
        print(f"标题: {detail.get('title')}")
        print(f"图片数量: {len(detail.get('content_images', []))}")
        
        if detail.get('content_images'):
            print("\n图片列表:")
            for i, img in enumerate(detail['content_images'][:5]):
                print(f"  {i+1}. {img[:80]}...")
        else:
            print("⚠️ 未找到图片，检查HTML结构...")
    
    print("\n" + "=" * 60)
    print("✅ 测试完成!")
    print("=" * 60)
    return True

if __name__ == '__main__':
    main()
