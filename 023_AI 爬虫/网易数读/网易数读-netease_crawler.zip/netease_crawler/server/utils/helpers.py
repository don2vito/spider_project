# -*- coding: utf-8 -*-
"""
网易数读栏目爬虫系统 - 工具函数
"""

import os
import re
import time
import random
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def get_random_user_agent() -> str:
    """获取随机User-Agent"""
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
    ]
    return random.choice(user_agents)


def get_request_headers() -> Dict[str, str]:
    """获取请求头"""
    return {
        "User-Agent": get_random_user_agent(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
        "Cache-Control": "max-age=0",
    }


def extract_article_id(url: str) -> Optional[str]:
    """从URL中提取文章ID"""
    # URL格式: https://www.163.com/data/article/KTP4DKNB00019GOE.html
    pattern = r'/article/([A-Z0-9]+)\.html'
    match = re.search(pattern, url)
    if match:
        return match.group(1)
    return None


def sanitize_filename(filename: str) -> str:
    """清理文件名，移除非法字符"""
    # 移除Windows不允许的字符
    illegal_chars = r'[<>:"/\\|?*]'
    filename = re.sub(illegal_chars, '_', filename)
    # 限制文件名长度
    if len(filename) > 200:
        filename = filename[:200]
    return filename.strip()


def delay_request(seconds: float = 1.0):
    """请求延迟"""
    time.sleep(seconds + random.uniform(0, 0.5))


def format_datetime(dt_str: str) -> str:
    """格式化日期时间字符串"""
    try:
        # 尝试解析原始格式
        dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S")
        return dt.strftime("%Y-%m-%d %H:%M")
    except:
        return dt_str


def ensure_dir(path: str):
    """确保目录存在"""
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)


def clean_json_string(s: str) -> str:
    """清理JSON字符串，处理单引号问题"""
    # 将JavaScript单引号字符串转换为双引号
    # 注意：这是一个简化的处理，可能不适用于所有情况
    return s


def parse_keywords(keyword_str: str) -> List[str]:
    """解析关键词字符串"""
    if not keyword_str:
        return []
    return [k.strip() for k in keyword_str.split(',') if k.strip()]
