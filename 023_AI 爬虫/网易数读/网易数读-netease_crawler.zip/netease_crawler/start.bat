@echo off
chcp 65001 >nul
title NetEase Data Blog Crawler

echo ==========================================
echo   NetEase Data Blog Crawler System
echo ==========================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Please install Python 3.8+
    pause
    exit /b 1
)

echo [INFO] Python found:
python --version

REM Get the directory where this batch file is located
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

REM Change to server directory
cd server

echo [INFO] Checking dependencies...
python -c "import flask, flask_cors, requests, bs4, PIL, reportlab" >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Some dependencies missing. Trying to install...
    pip install flask flask-cors requests beautifulsoup4 lxml Pillow reportlab --no-warn-script-location 2>nul
)

echo [INFO] Starting server...
start "Crawler Server" python app.py

echo [INFO] Waiting for server to start...
timeout /t 5 /nobreak >nul

echo [INFO] Opening browser...
start "" "http://127.0.0.1:5000"

echo.
echo ==========================================
echo   Server running at http://127.0.0.1:5000
echo   Press any key to stop server
echo ==========================================
pause >nul

echo [INFO] Stopping server...
taskkill /F /IM python.exe >nul 2>&1

echo [INFO] Done.
