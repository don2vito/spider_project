#!/bin/bash
# NetEase Data Blog Crawler - Linux/Mac启动脚本

echo "=========================================="
echo "  NetEase Data Blog Crawler System"
echo "=========================================="
echo

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python3 not found. Please install Python 3.8+"
    exit 1
fi

echo "[INFO] Python found:"
python3 --version

# Change to server directory
cd server

# Create venv if not exists
if [ ! -d "venv" ]; then
    echo "[INFO] Creating virtual environment..."
    python3 -m venv venv
fi

echo "[INFO] Activating virtual environment..."
source venv/bin/activate

echo "[INFO] Installing dependencies..."
pip install -q -r requirements.txt

echo "[INFO] Starting server..."
python app.py
