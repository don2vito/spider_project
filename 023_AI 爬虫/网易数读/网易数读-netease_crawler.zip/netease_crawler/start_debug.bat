@echo off
chcp 65001 >nul
title NetEase Data Blog Crawler - Debug Mode

echo ==========================================
echo   NetEase Data Blog Crawler System
echo   DEBUG MODE
echo ==========================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Please install Python 3.8+
    pause
    exit /b 1
)

echo [INFO] Python found:
python --version
echo.

REM Get the directory where this batch file is located
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

echo [INFO] Current directory: %CD%
echo.

REM Change to server directory
cd server
echo [INFO] Server directory: %CD%
echo.

echo [INFO] Checking Python packages...
python -c "import flask; print('Flask:', flask.__version__)" 2>&1
python -c "import requests; print('Requests: OK')" 2>&1
python -c "import bs4; print('BeautifulSoup: OK')" 2>&1
python -c "import PIL; print('Pillow: OK')" 2>&1
python -c "import reportlab; print('ReportLab: OK')" 2>&1
echo.

echo [INFO] Starting server in debug mode...
echo [INFO] If you see errors below, please screenshot them
echo ==========================================
echo.

python app.py

echo.
echo ==========================================
echo [INFO] Server stopped or failed to start
echo [INFO] Check error messages above
pause
