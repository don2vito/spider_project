# -*- coding: utf-8 -*-
"""
艾瑞咨询研究报告爬虫 - 核心爬取逻辑
实现三层爬取策略：API接口层 -> HTML解析层 -> Browser Use层
"""

import asyncio
import aiohttp
import requests
import json
import os
import re
import time
import random
import tempfile
from datetime import datetime
from typing import List, Dict, Optional, Any
from bs4 import BeautifulSoup
from pathlib import Path
from PIL import Image

# 基础配置
BASE_URL = "https://www.iresearch.com.cn"
API_LIST_URL = f"{BASE_URL}/api/products/GetReportList"
API_DETAIL_URL = f"{BASE_URL}/api/Detail/reportM"
REPORT_PAGE_URL = f"{BASE_URL}/report.shtml"

# 数据存储路径
DATA_DIR = Path(__file__).parent / "data"
DATA_FILE = DATA_DIR / "reports.json"
DOWNLOADS_DIR = Path(__file__).parent / "downloads"

# 请求头
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Referer': BASE_URL,
    'Connection': 'keep-alive'
}

# 爬取状态
class CrawlStatus:
    IDLE = 'idle'
    RUNNING = 'running'
    COMPLETED = 'completed'
    ERROR = 'error'


class IResearchCrawler:
    """艾瑞咨询报告爬虫"""
    
    def __init__(self):
        self.status = CrawlStatus.IDLE
        self.progress = 0
        self.total = 0
        self.current = 0
        self.message = ""
        self.all_reports: List[Dict] = []
        self.existing_ids: set = set()
        
        # 确保目录存在
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)
        
        # 加载已有数据
        self._load_existing_data()
    
    def _load_existing_data(self):
        """加载已有数据"""
        if DATA_FILE.exists():
            try:
                with open(DATA_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.all_reports = data.get('reports', [])
                    self.existing_ids = {r['id'] for r in self.all_reports}
            except Exception as e:
                print(f"加载数据失败: {e}")
                self.all_reports = []
                self.existing_ids = set()
    
    def _save_data(self):
        """保存数据到文件"""
        data = {
            'last_updated': datetime.now().isoformat(),
            'total_count': len(self.all_reports),
            'last_id': self.all_reports[0]['id'] if self.all_reports else "",
            'reports': self.all_reports
        }
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def _sanitize_filename(self, filename: str) -> str:
        """清理文件名，移除非法字符"""
        # 移除 Windows 不允许的字符
        illegal_chars = r'[<>:"/\\|?*]'
        filename = re.sub(illegal_chars, '_', filename)
        # 移除多余的空格和点
        filename = re.sub(r'\s+', ' ', filename).strip()
        # 限制文件名长度
        if len(filename) > 200:
            filename = filename[:200]
        return filename
    
    def _random_delay(self, min_ms: int = 300, max_ms: int = 800):
        """随机延迟，避免请求过于频繁"""
        delay = random.randint(min_ms, max_ms) / 1000
        time.sleep(delay)
    
    # ==================== 第一层：API 接口爬取 ====================
    
    def _fetch_report_list(self, last_id: str = "", page_size: int = 50) -> Optional[List[Dict]]:
        """获取报告列表（API层）"""
        try:
            params = {
                'fee': '0',
                'date': '',
                'lastId': last_id,
                'pageSize': page_size
            }
            response = requests.get(
                API_LIST_URL, 
                params=params, 
                headers=HEADERS, 
                timeout=30
            )
            response.raise_for_status()
            data = response.json()
            
            if data.get('Status') == 'success':
                return data.get('List', [])
            return None
        except Exception as e:
            print(f"获取报告列表失败: {e}")
            return None
    
    def _fetch_report_detail(self, news_id: int) -> Optional[Dict]:
        """获取报告详情（API层）"""
        try:
            params = {'id': news_id, 'isfree': '0'}
            response = requests.get(
                API_DETAIL_URL, 
                params=params, 
                headers=HEADERS, 
                timeout=30
            )
            response.raise_for_status()
            data = response.json()
            
            if data.get('Status') == 'success':
                details = data.get('List', [])
                return details[0] if details else None
            return None
        except Exception as e:
            print(f"获取报告详情失败 (ID: {news_id}): {e}")
            return None
    
    def _normalize_report(self, item: Dict, detail: Optional[Dict] = None) -> Dict:
        """标准化报告数据格式"""
        return {
            'id': item.get('Id', ''),
            'newsId': item.get('NewsId', 0),
            'title': item.get('Title', ''),
            'shortTitle': item.get('sTitle', ''),
            'content': item.get('Content', '')[:500] if item.get('Content') else '',
            'keywords': item.get('Keyword', []),
            'industry': item.get('industry', ''),
            'coverUrl': item.get('BigImg', ''),
            'thumbnailUrl': item.get('SmallImg', ''),
            'detailUrl': item.get('VisitUrl', ''),
            'publishDate': item.get('Uptime', ''),
            'author': item.get('Author', '艾瑞咨询'),
            'views': item.get('views', 0),
            'pageCount': detail.get('PagesCount', 0) if detail else 0,
            'price': item.get('Price', 0),
            'isFree': item.get('Price', 0) == 0,
            'downloaded': False,
            'pdfPath': None,
            'createdAt': datetime.now().isoformat(),
            'updatedAt': datetime.now().isoformat()
        }
    
    def crawl_api_layer(self) -> List[Dict]:
        """第一层：API 接口爬取"""
        print("开始 API 层爬取...")
        self.status = CrawlStatus.RUNNING
        self.message = "正在通过 API 获取报告列表..."
        
        all_reports = []
        last_id = ""
        page = 1
        
        while True:
            self.message = f"正在获取第 {page} 页数据..."
            self._random_delay()
            
            reports = self._fetch_report_list(last_id)
            if not reports:
                break
            
            # 处理每条报告
            for i, item in enumerate(reports):
                report_id = item.get('Id', '')
                
                # 去重检查
                if report_id in self.existing_ids:
                    continue
                
                # 获取详情
                self._random_delay(200, 500)
                detail = self._fetch_report_detail(item.get('NewsId', 0))
                
                # 标准化数据
                report = self._normalize_report(item, detail)
                all_reports.append(report)
                self.existing_ids.add(report_id)
                
                self.current += 1
                self.message = f"已获取 {len(all_reports)} 条新报告..."
            
            # 更新游标
            if reports:
                last_id = reports[-1].get('Id', '')
            
            page += 1
            self.progress = min(90, page * 5)  # 预估进度
            
            # 安全限制：最多爬取100页
            if page > 100:
                break
        
        self.progress = 95
        self.message = f"API 层爬取完成，共获取 {len(all_reports)} 条新报告"
        print(f"API 层爬取完成: {len(all_reports)} 条")
        
        return all_reports
    
    # ==================== 第二层：HTML 解析爬取 ====================
    
    def crawl_html_layer(self) -> List[Dict]:
        """第二层：HTML 解析爬取（备用）"""
        print("开始 HTML 层爬取...")
        self.message = "正在解析 HTML 页面..."
        
        try:
            response = requests.get(REPORT_PAGE_URL, headers=HEADERS, timeout=30)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'lxml')
            
            reports = []
            # 根据实际 DOM 结构解析
            # 这里需要根据网站实际结构调整选择器
            items = soup.select('.report-item, .list-item, [class*="report"]')
            
            for item in items:
                try:
                    title_elem = item.select_one('a[title], .title, h3, h4')
                    link_elem = item.select_one('a[href]')
                    img_elem = item.select_one('img[src]')
                    
                    if title_elem and link_elem:
                        title = title_elem.get_text(strip=True)
                        link = link_elem.get('href', '')
                        img = img_elem.get('src', '') if img_elem else ''
                        
                        if link and not link.startswith('http'):
                            link = BASE_URL + link
                        
                        report = {
                            'id': f"html_{hash(title)}",
                            'newsId': 0,
                            'title': title,
                            'detailUrl': link,
                            'coverUrl': img,
                            'industry': '',
                            'publishDate': '',
                            'isFree': True,
                            'downloaded': False,
                            'createdAt': datetime.now().isoformat()
                        }
                        reports.append(report)
                except Exception as e:
                    continue
            
            print(f"HTML 层爬取完成: {len(reports)} 条")
            return reports
            
        except Exception as e:
            print(f"HTML 层爬取失败: {e}")
            return []
    
    # ==================== 第三层：Browser Use 爬取 ====================
    
    async def crawl_browser_layer(self) -> List[Dict]:
        """第三层：Browser Use 爬取（兜底）"""
        print("开始 Browser Use 层爬取...")
        self.message = "正在启动浏览器..."
        
        try:
            from playwright.async_api import async_playwright
            
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                page = await browser.new_page()
                
                await page.goto(REPORT_PAGE_URL, wait_until='networkidle')
                await page.wait_for_timeout(2000)
                
                # 提取数据
                reports = await page.evaluate('''() => {
                    const items = document.querySelectorAll('[class*="report"], .list-item');
                    return Array.from(items).map(item => {
                        const titleElem = item.querySelector('a[title], .title, h3, h4');
                        const linkElem = item.querySelector('a[href]');
                        const imgElem = item.querySelector('img[src]');
                        return {
                            title: titleElem ? titleElem.innerText.trim() : '',
                            link: linkElem ? linkElem.href : '',
                            image: imgElem ? imgElem.src : ''
                        };
                    }).filter(r => r.title && r.link);
                }''')
                
                await browser.close()
                
                # 标准化
                result = []
                for r in reports:
                    result.append({
                        'id': f"browser_{hash(r['title'])}",
                        'newsId': 0,
                        'title': r['title'],
                        'detailUrl': r['link'],
                        'coverUrl': r['image'],
                        'industry': '',
                        'publishDate': '',
                        'isFree': True,
                        'downloaded': False,
                        'createdAt': datetime.now().isoformat()
                    })
                
                print(f"Browser Use 层爬取完成: {len(result)} 条")
                return result
                
        except Exception as e:
            print(f"Browser Use 层爬取失败: {e}")
            return []
    
    # ==================== 主爬取方法 ====================
    
    def crawl(self, force_full: bool = False) -> Dict:
        """执行爬取（三层策略）"""
        try:
            self.status = CrawlStatus.RUNNING
            self.progress = 0
            self.current = 0
            self.message = "开始爬取..."
            
            # 第一层：API 接口
            new_reports = self.crawl_api_layer()
            
            # 如果 API 层获取到数据，直接使用
            if new_reports:
                self.all_reports = new_reports + self.all_reports
            else:
                # 尝试第二层：HTML 解析
                self.message = "API 层未获取到数据，尝试 HTML 解析..."
                html_reports = self.crawl_html_layer()
                
                if html_reports:
                    # 过滤已存在的
                    html_reports = [r for r in html_reports if r['id'] not in self.existing_ids]
                    self.all_reports = html_reports + self.all_reports
                else:
                    # 尝试第三层：Browser Use
                    self.message = "HTML 层未获取到数据，尝试 Browser Use..."
                    browser_reports = asyncio.run(self.crawl_browser_layer())
                    
                    if browser_reports:
                        browser_reports = [r for r in browser_reports if r['id'] not in self.existing_ids]
                        self.all_reports = browser_reports + self.all_reports
            
            # 保存数据
            self._save_data()
            
            self.status = CrawlStatus.COMPLETED
            self.progress = 100
            self.message = f"爬取完成，共 {len(self.all_reports)} 条报告"
            
            return {
                'success': True,
                'status': self.status,
                'total': len(self.all_reports),
                'new': len(new_reports),
                'message': self.message
            }
            
        except Exception as e:
            self.status = CrawlStatus.ERROR
            self.message = f"爬取失败: {str(e)}"
            return {
                'success': False,
                'status': self.status,
                'message': self.message,
                'error': str(e)
            }
    
    def get_status(self) -> Dict:
        """获取爬取状态"""
        return {
            'status': self.status,
            'progress': self.progress,
            'total': self.total or len(self.all_reports),
            'current': self.current,
            'message': self.message
        }
    
    # ==================== 数据查询方法 ====================
    
    def get_reports(self, page: int = 1, page_size: int = 20, 
                    search: str = '', industry: str = '', 
                    date_start: str = '', date_end: str = '',
                    sort_by: str = 'publishDate', sort_order: str = 'desc') -> Dict:
        """获取报告列表（支持搜索、筛选、排序、分页）"""
        
        # 筛选
        filtered = self.all_reports.copy()
        
        # 搜索
        if search:
            search_lower = search.lower()
            filtered = [r for r in filtered if search_lower in r.get('title', '').lower()]
        
        # 行业筛选
        if industry:
            filtered = [r for r in filtered if r.get('industry') == industry]
        
        # 时间筛选
        if date_start:
            filtered = [r for r in filtered if r.get('publishDate', '') >= date_start]
        if date_end:
            filtered = [r for r in filtered if r.get('publishDate', '') <= date_end]
        
        # 排序
        reverse = sort_order == 'desc'
        if sort_by == 'publishDate':
            # 按日期排序，处理格式如 "2026/5/26" 或 "2026/5/26 10:30:00"
            def parse_date(x):
                date_str = x.get('publishDate', '')
                if not date_str:
                    return datetime.min
                try:
                    # 尝试解析 "2026/5/26" 或 "2026/5/26 10:30:00" 格式
                    for fmt in ['%Y/%m/%d %H:%M:%S', '%Y/%m/%d', '%Y-%m-%d']:
                        try:
                            return datetime.strptime(date_str.strip(), fmt)
                        except ValueError:
                            continue
                    # 如果都失败，返回最小日期
                    return datetime.min
                except Exception:
                    return datetime.min
            filtered.sort(key=parse_date, reverse=reverse)
        elif sort_by == 'views':
            filtered.sort(key=lambda x: x.get('views', 0), reverse=reverse)
        elif sort_by == 'title':
            filtered.sort(key=lambda x: x.get('title', ''), reverse=reverse)
        
        # 分页
        total = len(filtered)
        start = (page - 1) * page_size
        end = start + page_size
        paged = filtered[start:end]
        
        return {
            'list': paged,
            'total': total,
            'page': page,
            'pageSize': page_size,
            'totalPages': (total + page_size - 1) // page_size
        }
    
    def get_report_by_id(self, report_id: str) -> Optional[Dict]:
        """获取单个报告详情"""
        for report in self.all_reports:
            if report.get('id') == report_id:
                return report
        return None
    
    def get_industries(self) -> List[str]:
        """获取所有行业分类"""
        industries = set()
        for report in self.all_reports:
            industry = report.get('industry', '')
            if industry:
                industries.add(industry)
        return sorted(list(industries))
    
    def get_stats(self) -> Dict:
        """获取统计数据"""
        total = len(self.all_reports)
        free_count = sum(1 for r in self.all_reports if r.get('isFree'))
        downloaded_count = sum(1 for r in self.all_reports if r.get('downloaded'))
        
        # 读取最后更新时间
        last_updated = None
        if DATA_FILE.exists():
            try:
                with open(DATA_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    last_updated = data.get('last_updated')
            except:
                pass
        
        return {
            'totalCount': total,
            'freeCount': free_count,
            'paidCount': total - free_count,
            'downloadedCount': downloaded_count,
            'lastCrawlTime': last_updated,
            'crawlStatus': self.status
        }
    
    # ==================== 下载方法 ====================
    
    def _detect_page_count(self, news_id: int) -> int:
        """探测报告总页数"""
        # 先用 pageCount 字段（来自 API 详情）
        for report in self.all_reports:
            if report.get('newsId') == news_id and report.get('pageCount', 0) > 0:
                return report['pageCount']
        
        # 用二分法探测
        base_url = f"https://pic.iresearch.cn/rimgs/{news_id}/"
        low, high = 1, 200
        while low <= high:
            mid = (low + high) // 2
            code = requests.head(base_url + f"{mid}.jpg", headers=HEADERS, timeout=10, allow_redirects=True).status_code
            if code == 200:
                low = mid + 1
            else:
                high = mid - 1
        return high if high >= 1 else 0
    
    def download_pdf(self, report_id: str) -> Dict:
        """下载单个报告 PDF（从报告图片合成）"""
        report = self.get_report_by_id(report_id)
        if not report:
            return {'success': False, 'message': '报告不存在'}
        
        news_id = report.get('newsId', 0)
        if not news_id:
            # 尝试从 id 中提取
            match = re.search(r'(\d+)', report_id)
            if match:
                news_id = int(match.group(1))
            else:
                return {'success': False, 'message': '无法获取报告 ID'}
        
        try:
            # 1. 探测总页数
            self._random_delay(200, 500)
            total_pages = self._detect_page_count(news_id)
            
            if total_pages == 0:
                return {'success': False, 'message': '无法获取报告页面'}
            
            print(f"报告 {news_id} 共 {total_pages} 页，开始下载图片...")
            
            # 2. 下载所有页面图片到临时目录
            tmp_dir = Path(tempfile.mkdtemp(prefix=f"ireport_{news_id}_"))
            base_url = f"https://pic.iresearch.cn/rimgs/{news_id}/"
            images = []
            
            for page_num in range(1, total_pages + 1):
                img_url = base_url + f"{page_num}.jpg"
                try:
                    self._random_delay(100, 300)
                    resp = requests.get(img_url, headers=HEADERS, timeout=30)
                    if resp.status_code == 200:
                        img_path = tmp_dir / f"{page_num}.jpg"
                        with open(img_path, 'wb') as f:
                            f.write(resp.content)
                        images.append(Image.open(img_path).convert('RGB'))
                    else:
                        print(f"  页 {page_num} 下载失败: HTTP {resp.status_code}")
                except Exception as e:
                    print(f"  页 {page_num} 下载异常: {e}")
            
            if not images:
                # 清理临时目录
                import shutil
                shutil.rmtree(tmp_dir, ignore_errors=True)
                return {'success': False, 'message': '所有页面图片下载失败'}
            
            # 3. 合并为 PDF
            filename = self._sanitize_filename(report.get('title', f'report_{news_id}')) + '.pdf'
            filepath = DOWNLOADS_DIR / filename
            
            first_img = images[0]
            other_imgs = images[1:]
            
            first_img.save(
                filepath,
                'PDF',
                resolution=100,
                save_all=True,
                append_images=other_imgs
            )
            
            # 4. 清理临时目录
            import shutil
            shutil.rmtree(tmp_dir, ignore_errors=True)
            
            # 5. 更新报告状态
            report['downloaded'] = True
            report['pdfPath'] = str(filepath)
            self._save_data()
            
            print(f"报告下载成功: {filename} ({total_pages} 页)")
            return {
                'success': True,
                'message': f'下载成功 ({total_pages} 页)',
                'filename': filename,
                'filepath': str(filepath),
                'pages': total_pages
            }
            
        except Exception as e:
            import shutil
            import traceback
            traceback.print_exc()
            # 清理临时目录
            try:
                shutil.rmtree(tmp_dir, ignore_errors=True)
            except:
                pass
            return {'success': False, 'message': f'下载失败: {str(e)}'}
    
    def mark_downloaded(self, report_id: str, filepath: str):
        """标记报告已下载"""
        for report in self.all_reports:
            if report.get('id') == report_id:
                report['downloaded'] = True
                report['pdfPath'] = filepath
                break
        self._save_data()


# 全局爬虫实例
crawler = IResearchCrawler()
