# -*- coding: utf-8 -*-
"""
艾瑞咨询研究报告爬虫 - Flask 代理服务器
提供 API 接口和用户认证功能
"""

from flask import Flask, request, jsonify, send_file, send_from_directory
from flask_cors import CORS
import jwt
import datetime
import os
import json
import re
from pathlib import Path
from functools import wraps

from crawler import crawler, DOWNLOADS_DIR

# 创建 Flask 应用
app = Flask(__name__, static_folder='.', static_url_path='')
CORS(app)

# JWT 密钥
SECRET_KEY = 'iresearch_crawler_secret_key_2026'

# 验证码存储（模拟）
verification_codes = {}

# 用户存储（模拟）
users_db = {}


# ==================== 认证装饰器 ====================

def token_required(f):
    """JWT Token 验证装饰器"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization', '')
        
        if not token:
            return jsonify({'success': False, 'message': '缺少认证令牌'}), 401
        
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            
            data = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
            request.user = data
            
        except jwt.ExpiredSignatureError:
            return jsonify({'success': False, 'message': '令牌已过期'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'success': False, 'message': '无效令牌'}), 401
        
        return f(*args, **kwargs)
    
    return decorated


# ==================== 认证 API ====================

@app.route('/api/auth/login', methods=['POST'])
def send_verification_code():
    """发送验证码（模拟）"""
    data = request.get_json() or {}
    phone = data.get('phone', '')
    
    # 验证手机号格式
    if not re.match(r'^1[3-9]\d{9}$', phone):
        return jsonify({'success': False, 'message': '请输入正确的手机号'})
    
    # 生成验证码（模拟，固定为 123456）
    code = '123456'
    verification_codes[phone] = {
        'code': code,
        'expire': datetime.datetime.now().timestamp() + 300  # 5分钟有效
    }
    
    # 实际项目中这里应该调用短信服务发送验证码
    print(f"[模拟] 向 {phone} 发送验证码: {code}")
    
    return jsonify({
        'success': True,
        'message': '验证码已发送',
        # 模拟环境返回验证码，生产环境应删除
        'code': code
    })


@app.route('/api/auth/verify', methods=['POST'])
def verify_and_login():
    """验证验证码并登录"""
    data = request.get_json() or {}
    phone = data.get('phone', '')
    code = data.get('code', '')
    
    # 验证手机号
    if not re.match(r'^1[3-9]\d{9}$', phone):
        return jsonify({'success': False, 'message': '请输入正确的手机号'})
    
    # 验证验证码
    stored = verification_codes.get(phone)
    if not stored:
        return jsonify({'success': False, 'message': '请先获取验证码'})
    
    if datetime.datetime.now().timestamp() > stored['expire']:
        return jsonify({'success': False, 'message': '验证码已过期'})
    
    if code != stored['code']:
        return jsonify({'success': False, 'message': '验证码错误'})
    
    # 清除验证码
    del verification_codes[phone]
    
    # 创建或获取用户
    if phone not in users_db:
        users_db[phone] = {
            'id': f'user_{phone}',
            'phone': phone,
            'nickname': f'用户{phone[-4:]}',
            'createdAt': datetime.datetime.now().isoformat()
        }
    
    user = users_db[phone]
    
    # 生成 JWT Token
    token = jwt.encode({
        'userId': user['id'],
        'phone': user['phone'],
        'exp': datetime.datetime.now() + datetime.timedelta(days=7)
    }, SECRET_KEY, algorithm='HS256')
    
    return jsonify({
        'success': True,
        'message': '登录成功',
        'token': token,
        'user': {
            'id': user['id'],
            'phone': user['phone'],
            'nickname': user['nickname'],
            'phoneMasked': phone[:3] + '****' + phone[-4:]
        }
    })


@app.route('/api/auth/logout', methods=['POST'])
def logout():
    """退出登录"""
    return jsonify({'success': True, 'message': '已退出登录'})


@app.route('/api/auth/status', methods=['GET'])
def check_auth_status():
    """检查登录状态"""
    token = request.headers.get('Authorization', '')
    
    if not token:
        return jsonify({'isLoggedIn': False})
    
    try:
        if token.startswith('Bearer '):
            token = token[7:]
        
        data = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        phone = data.get('phone', '')
        user = users_db.get(phone, {})
        
        return jsonify({
            'isLoggedIn': True,
            'user': {
                'id': data.get('userId'),
                'phone': phone,
                'nickname': user.get('nickname', ''),
                'phoneMasked': phone[:3] + '****' + phone[-4:]
            }
        })
        
    except:
        return jsonify({'isLoggedIn': False})


# ==================== 爬取 API ====================

@app.route('/api/crawl', methods=['GET'])
def start_crawl():
    """触发爬取任务"""
    force_full = request.args.get('force', '0') == '1'
    
    # 在后台执行爬取（简化版，直接同步执行）
    result = crawler.crawl(force_full)
    
    return jsonify(result)


@app.route('/api/crawl/status', methods=['GET'])
def get_crawl_status():
    """获取爬取状态"""
    return jsonify(crawler.get_status())


# ==================== 报告 API ====================

@app.route('/api/reports', methods=['GET'])
def get_reports():
    """获取报告列表"""
    page = int(request.args.get('page', 1))
    page_size = int(request.args.get('pageSize', 20))
    search = request.args.get('search', '')
    industry = request.args.get('industry', '')
    date_start = request.args.get('dateStart', '')
    date_end = request.args.get('dateEnd', '')
    sort_by = request.args.get('sortBy', 'publishDate')
    sort_order = request.args.get('sortOrder', 'desc')
    
    result = crawler.get_reports(
        page=page,
        page_size=page_size,
        search=search,
        industry=industry,
        date_start=date_start,
        date_end=date_end,
        sort_by=sort_by,
        sort_order=sort_order
    )
    
    return jsonify({'success': True, 'data': result})


@app.route('/api/reports/<report_id>', methods=['GET'])
def get_report(report_id):
    """获取单个报告详情"""
    report = crawler.get_report_by_id(report_id)
    
    if report:
        return jsonify({'success': True, 'data': report})
    else:
        return jsonify({'success': False, 'message': '报告不存在'}), 404


@app.route('/api/industries', methods=['GET'])
def get_industries():
    """获取行业分类列表"""
    industries = crawler.get_industries()
    return jsonify({'success': True, 'data': industries})


@app.route('/api/stats', methods=['GET'])
def get_stats():
    """获取统计数据"""
    stats = crawler.get_stats()
    return jsonify({'success': True, 'data': stats})


# ==================== 下载 API ====================

@app.route('/api/download/<report_id>', methods=['GET'])
@token_required
def download_report(report_id):
    """下载单个报告 PDF"""
    result = crawler.download_pdf(report_id)
    
    if result.get('success'):
        filepath = result.get('filepath')
        filename = result.get('filename')
        
        return send_file(
            filepath,
            as_attachment=True,
            download_name=filename
        )
    else:
        return jsonify(result), 400


@app.route('/api/download/batch', methods=['POST'])
@token_required
def batch_download():
    """批量下载报告"""
    data = request.get_json() or {}
    ids = data.get('ids', [])
    
    if not ids:
        return jsonify({'success': False, 'message': '请选择要下载的报告'})
    
    results = []
    for report_id in ids:
        result = crawler.download_pdf(report_id)
        results.append({
            'id': report_id,
            'success': result.get('success', False),
            'message': result.get('message', ''),
            'filename': result.get('filename', '')
        })
    
    success_count = sum(1 for r in results if r['success'])
    
    return jsonify({
        'success': True,
        'message': f'成功下载 {success_count}/{len(ids)} 个报告',
        'results': results
    })


@app.route('/api/download/file/<filename>', methods=['GET'])
def download_file(filename):
    """下载已存在的 PDF 文件"""
    filepath = DOWNLOADS_DIR / filename
    if filepath.exists():
        return send_file(filepath, as_attachment=True)
    else:
        return jsonify({'success': False, 'message': '文件不存在'}), 404


# ==================== 静态文件服务 ====================

@app.route('/')
def index():
    """返回前端页面"""
    return send_from_directory('.', 'index.html')


@app.route('/<path:path>')
def serve_static(path):
    """服务静态文件"""
    if os.path.exists(path):
        return send_from_directory('.', path)
    else:
        return send_from_directory('.', 'index.html')


# ==================== 启动服务器 ====================

if __name__ == '__main__':
    print("=" * 50)
    print("  艾瑞咨询研究报告爬虫系统")
    print("  服务器启动中...")
    print("=" * 50)
    print(f"  访问地址: http://localhost:5000")
    print(f"  数据目录: {Path(__file__).parent / 'data'}")
    print(f"  下载目录: {DOWNLOADS_DIR}")
    print("=" * 50)
    
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
