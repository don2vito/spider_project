@echo off
chcp 65001 >nul
echo ==========================================
echo   iResearch Report Crawler System
echo ==========================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Please install Python 3.8+
    pause
    exit /b 1
)

:: Get script directory
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

:: Install dependencies
echo [1/3] Installing dependencies...

:: Upgrade pip first to avoid version parsing issues
python -m pip install --upgrade pip --quiet 2>nul

:: Install packages one by one to avoid dependency conflicts
echo   - Installing Flask...
pip install flask>=2.3.0 --quiet 2>nul
if errorlevel 1 pip install flask>=2.3.0

echo   - Installing Flask-CORS...
pip install flask-cors>=4.0.0 --quiet 2>nul
if errorlevel 1 pip install flask-cors>=4.0.0

echo   - Installing requests...
pip install requests>=2.31.0 --quiet 2>nul
if errorlevel 1 pip install requests>=2.31.0

echo   - Installing Pillow (for PDF generation)...
pip install Pillow>=10.0.0 --quiet 2>nul
if errorlevel 1 pip install Pillow>=10.0.0

echo   - Installing other dependencies...
pip install beautifulsoup4>=4.12.0 lxml>=4.9.0 pyjwt>=2.8.0 python-dateutil>=2.8.0 --quiet 2>nul
if errorlevel 1 pip install beautifulsoup4>=4.12.0 lxml>=4.9.0 pyjwt>=2.8.0 python-dateutil>=2.8.0

:: Optional: aiohttp and playwright (for advanced crawling)
pip install aiohttp>=3.8.0 --quiet 2>nul

echo [2/3] Starting proxy server...
start "iResearch Crawler Server" python server.py

:: Wait for server
echo [3/3] Waiting for server to start...
timeout /t 3 /nobreak >nul

:: Open browser
echo Opening browser...
start http://localhost:5000

echo.
echo ==========================================
echo   System started successfully!
echo   Server: http://localhost:5000
   Press Ctrl+C in server window to stop
echo ==========================================
echo.
pause
